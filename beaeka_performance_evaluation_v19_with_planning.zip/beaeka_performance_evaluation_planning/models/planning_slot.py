from odoo import fields, models


class PlanningSlot(models.Model):
    _inherit = 'planning.slot'

    pe_plan_id = fields.Many2one('pe.plan', string='Annual plan', index=True, ondelete='set null', copy=False)
    pe_staffing_id = fields.Many2one('pe.plan.staffing', string='Plan staffing line', index=True, ondelete='set null',
                                     copy=False)
    pe_directorate_id = fields.Many2one('pe.directorate', string='Directorate', index=True, ondelete='set null')
