from collections import defaultdict
from datetime import datetime, time

import pytz
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from odoo.addons.beaeka_performance_evaluation.models.pe_plan import MONTH_FIELDS

DEFAULT_TZ = 'Africa/Addis_Ababa'


class PePlan(models.Model):
    _inherit = 'pe.plan'

    staffing_ids = fields.One2many('pe.plan.staffing', 'plan_id', string='Staffing', copy=True)
    slot_ids = fields.One2many('planning.slot', 'pe_plan_id', string='Shifts')
    slot_count = fields.Integer('Shifts', compute='_compute_slot_count')

    def _compute_slot_count(self):
        data = self.env['planning.slot'].sudo()._read_group([('pe_plan_id', 'in', self.ids)], ['pe_plan_id'], ['__count'])
        counts = {plan.id: count for plan, count in data}
        for rec in self:
            rec.slot_count = counts.get(rec.id, 0)

    # ------------------------------------------------------------------ helpers
    def _pe_tz(self):
        return pytz.timezone(self.env.user.tz or self.directorate_id.director_id.tz or DEFAULT_TZ)

    def _pe_month(self, index):
        """(first day, last day) of plan month index 1..12."""
        start = self.date_start.replace(day=1) + relativedelta(months=index - 1)
        return start, start + relativedelta(months=1, days=-1)

    @api.model
    def _pe_shift_action(self):
        try:
            action = self.env['ir.actions.act_window']._for_xml_id('planning.planning_action_schedule_by_resource')
        except Exception:  # noqa: BLE001 - planning action renamed: fall back to a plain action
            action = {'type': 'ir.actions.act_window', 'res_model': 'planning.slot', 'view_mode': 'gantt,list,form'}
        action['name'] = _('Shifts')
        return action

    def _pe_draft_slots(self):
        slots = self.sudo().slot_ids
        return slots.filtered(lambda s: s.state == 'draft') if 'state' in slots._fields else slots

    # ------------------------------------------------------------------ shift generation
    def _pe_generate_shifts(self):
        Slot = self.env['planning.slot'].sudo()
        for plan in self:
            if not plan.staffing_ids:
                continue
            plan._pe_draft_slots().unlink()
            tz = plan._pe_tz()

            def to_utc(day, at):
                return tz.localize(datetime.combine(day, at)).astimezone(pytz.utc).replace(tzinfo=None)

            kept = defaultdict(int)  # published shifts already in Planning, per (line, month)
            for slot in plan.sudo().slot_ids:
                if slot.pe_staffing_id:
                    kept[(slot.pe_staffing_id.id, slot.start_datetime)] += 1
            vals_list = []
            for line in plan.staffing_ids:
                for index in range(line.month_from, line.month_to + 1):
                    first, last = plan._pe_month(index)
                    start, end = to_utc(first, time(0, 0)), to_utc(last, time(23, 59, 59))
                    wanted = 1 if line.employee_id else line.headcount
                    for _i in range(max(wanted - kept[(line.id, start)], 0)):
                        vals_list.append({
                            'start_datetime': start,
                            'end_datetime': end,
                            'role_id': line.role_id.id,
                            'resource_id': line.employee_id.resource_id.id or False,
                            'allocated_percentage': line.allocated_percentage,
                            'company_id': plan.company_id.id,
                            'name': line.note or plan.name,
                            'pe_plan_id': plan.id,
                            'pe_staffing_id': line.id,
                            'pe_directorate_id': plan.directorate_id.id,
                        })
            created = Slot.create(vals_list) if vals_list else Slot
            plan._pe_fill_planned_hours()
            plan.message_post(body=_('%(new)s shift(s) created in Planning from the staffing table (unpublished: '
                                     'review and publish them in Planning). %(kept)s published shift(s) kept.',
                                     new=len(created), kept=sum(kept.values())))

    def _pe_fill_planned_hours(self):
        """Write the monthly hours of the generated shifts into the 'planned hours' KPI lines."""
        for plan in self:
            lines = plan.line_ids.filtered(lambda l: l.kpi_id.measure == 'planning_hours')
            if not lines:
                continue
            tz = plan._pe_tz()
            hours = [0.0] * 12
            for slot in plan.sudo().slot_ids:
                local = pytz.utc.localize(slot.start_datetime).astimezone(tz).date()
                first = plan.date_start.replace(day=1)
                index = (local.year - first.year) * 12 + local.month - first.month
                if 0 <= index < 12:
                    hours[index] += slot.allocated_hours or 0.0
            vals = {f: round(h, 2) for f, h in zip(MONTH_FIELDS, hours)}
            vals['annual_amount'] = round(sum(hours), 2)
            lines.write(vals)

    # ------------------------------------------------------------------ workflow
    def action_approve(self):
        to_plan = self.filtered('staffing_ids')
        res = super().action_approve()
        to_plan._pe_generate_shifts()
        return res

    def action_generate_shifts(self):
        if not self.staffing_ids:
            raise UserError(_('Add at least one line to the Staffing table first.'))
        self._pe_generate_shifts()
        self.env['pe.scorecard'].sudo().search([('directorate_id', 'in', self.directorate_id.ids),
                                                ('state', '!=', 'done')]).action_compute(notify=False)

    def _pe_remove_draft_shifts(self):
        for plan in self:
            drafts = plan._pe_draft_slots()
            published = len(plan.slot_ids) - len(drafts)
            if drafts:
                drafts.unlink()
            if drafts or published:
                plan.message_post(body=_('%(removed)s unpublished shift(s) removed from Planning. %(kept)s published '
                                         'shift(s) kept: change them in Planning if needed.',
                                         removed=len(drafts), kept=published))

    def action_draft(self):
        self._pe_remove_draft_shifts()
        return super().action_draft()

    def action_cancel(self):
        self._pe_remove_draft_shifts()
        return super().action_cancel()

    def action_view_shifts(self):
        self.ensure_one()
        action = self._pe_shift_action()
        action['domain'] = [('pe_plan_id', '=', self.id)]
        action['context'] = {'default_pe_plan_id': self.id, 'default_pe_directorate_id': self.directorate_id.id}
        return action


class PePlanStaffing(models.Model):
    _name = 'pe.plan.staffing'
    _description = 'Annual Plan Staffing Line'
    _order = 'sequence, id'

    plan_id = fields.Many2one('pe.plan', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='plan_id.company_id', store=True)
    sequence = fields.Integer(default=10)
    role_id = fields.Many2one('planning.role', string='Role', required=True)
    employee_id = fields.Many2one('hr.employee', string='Employee',
                                  domain="[('company_id', 'in', (company_id, False))]",
                                  help='Leave empty to create open shifts that the planner assigns later.')
    headcount = fields.Integer('People', default=1, help='Number of open shifts per month (1 when an employee is set).')
    allocated_percentage = fields.Float('Time %', default=100.0, help='100 = full time, 50 = half time.')
    month_from = fields.Integer('From month', default=1, help='Plan month 1-12 (M01 = first month of the plan).')
    month_to = fields.Integer('To month', default=12)
    note = fields.Char('Shift note')
    slot_count = fields.Integer('Shifts', compute='_compute_slot_count')

    _months_check = models.Constraint(
        'CHECK(month_from >= 1 AND month_to <= 12 AND month_from <= month_to)',
        'Staffing months must be between 1 and 12, "From" before "To".',
    )
    _headcount_check = models.Constraint('CHECK(headcount >= 1)', 'People must be at least 1.')

    def _compute_slot_count(self):
        data = self.env['planning.slot'].sudo()._read_group([('pe_staffing_id', 'in', self.ids)], ['pe_staffing_id'],
                                                            ['__count'])
        counts = {line.id: count for line, count in data}
        for rec in self:
            rec.slot_count = counts.get(rec.id, 0)

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id:
            self.headcount = 1
            if not self.role_id and 'default_planning_role_id' in self.employee_id._fields:
                self.role_id = self.employee_id.default_planning_role_id
