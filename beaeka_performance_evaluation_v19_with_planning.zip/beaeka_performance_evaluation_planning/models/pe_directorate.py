from odoo import api, fields, models, _
from odoo.fields import Domain

from odoo.addons.beaeka_performance_evaluation.models.pe_directorate import dt_range

PLANNING_MEASURES = [
    ('planning_hours', 'Planning: planned hours (published shifts)'),
    ('planning_worked', 'Planning: worked hours (attendance / timesheets)'),
    ('planning_utilisation', 'Planning: worked ÷ planned hours'),
    ('planning_fill_rate', 'Planning: shifts staffed (assigned ÷ all shifts)'),
]
PLANNING_KEYS = [key for key, _label in PLANNING_MEASURES]
PLANNING_RATIO = ('planning_utilisation', 'planning_fill_rate')


def slot_hours(slot, start, end):
    """Allocated hours of a shift that fall inside [start, end], prorated by time."""
    s, e = slot.start_datetime, slot.end_datetime
    total = (e - s).total_seconds() if s and e else 0
    if total <= 0:
        return 0.0
    overlap = (min(e, end) - max(s, start)).total_seconds()
    return (slot.allocated_hours or 0.0) * max(overlap, 0.0) / total


class PeDirectorate(models.Model):
    _inherit = 'pe.directorate'

    pe_worked_source = fields.Selection(
        [('auto', 'Automatic'), ('attendance', 'Attendances'), ('timesheet', 'Timesheets')],
        string='Worked hours from', default='auto', required=True,
        help='Source of worked hours for the Planning KPIs. Automatic uses Attendances when the app is installed, '
             'otherwise Timesheets.')
    pe_slot_count = fields.Integer('Shifts', compute='_compute_pe_slot_count')

    # ------------------------------------------------------------------ shifts of the directorate
    def _pe_slot_domain(self):
        """Shifts created from this directorate's plans, plus shifts of its employees."""
        self.ensure_one()
        parts = [[('pe_directorate_id', '=', self.id)]]
        employees = self._employees()
        if employees.resource_id:
            parts.append([('resource_id', 'in', employees.resource_id.ids)])
        return Domain.AND([[('company_id', '=', self.company_id.id)], Domain.OR(parts)])

    def _compute_pe_slot_count(self):
        Slot = self.env['planning.slot'].sudo()
        for rec in self:
            rec.pe_slot_count = Slot.search_count(rec._pe_slot_domain()) if rec.id else 0

    def _pe_slots(self, date_from, date_to, assigned_only=False):
        Slot = self.env['planning.slot'].sudo()
        start, end = dt_range(date_from, date_to)
        dom = Domain.AND([self._pe_slot_domain(), [('start_datetime', '<=', end), ('end_datetime', '>=', start)]])
        if 'state' in Slot._fields:
            dom = Domain.AND([dom, [('state', '=', 'published')]])
        if assigned_only:
            dom = Domain.AND([dom, [('resource_id', '!=', False)]])
        return Slot.search(dom), start, end

    def _pe_worked_hours(self, date_from, date_to, employees):
        """Worked hours of these employees in the range, or None when no source is installed."""
        if not employees:
            return None
        source = self.pe_worked_source
        if source in ('auto', 'attendance') and 'hr.attendance' in self.env:
            start, end = dt_range(date_from, date_to)
            atts = self.env['hr.attendance'].sudo().search([('employee_id', 'in', employees.ids),
                                                            ('check_in', '>=', start), ('check_in', '<=', end),
                                                            ('check_out', '!=', False)])
            return sum(atts.mapped('worked_hours'))
        if source == 'attendance':
            return None
        AAL = self.env['account.analytic.line'].sudo()
        if 'employee_id' not in AAL._fields:
            return None
        dom = [('employee_id', 'in', employees.ids), ('date', '>=', date_from), ('date', '<=', date_to)]
        if 'project_id' in AAL._fields:
            dom.append(('project_id', '!=', False))
        return sum(AAL.search(dom).mapped('unit_amount'))

    def _slot_employees(self, slots):
        if 'employee_id' in slots._fields:
            return slots.mapped('employee_id')
        return self.env['hr.employee'].sudo().search([('resource_id', 'in', slots.resource_id.ids)])

    def measure_value(self, measure, date_from, date_to):
        if measure not in PLANNING_KEYS:
            return super().measure_value(measure, date_from, date_to)
        self.ensure_one()
        if measure == 'planning_hours':
            slots, start, end = self._pe_slots(date_from, date_to)
            if not slots:
                return None
            return {'actual': sum(slot_hours(s, start, end) for s in slots)}
        if measure == 'planning_worked':
            worked = self._pe_worked_hours(date_from, date_to, self._employees())
            return None if worked is None else {'actual': worked}
        if measure == 'planning_utilisation':
            slots, start, end = self._pe_slots(date_from, date_to, assigned_only=True)
            planned = sum(slot_hours(s, start, end) for s in slots)
            if not planned:
                return None
            worked = self._pe_worked_hours(date_from, date_to, self._slot_employees(slots))
            return None if worked is None else {'num': worked, 'den': planned}
        if measure == 'planning_fill_rate':
            slots, _start, _end = self._pe_slots(date_from, date_to)
            if not slots:
                return None
            return {'num': float(len(slots.filtered('resource_id'))), 'den': float(len(slots))}
        return None

    @api.depends('analytic_account_ids', 'team_ids', 'company_wide', 'kpi_ids.measure')
    def _compute_link_warning(self):
        super()._compute_link_warning()
        for rec in self:
            if rec.link_warning:
                needs = rec.kpi_ids.filtered(lambda k: k.active and k.measure not in ('manual', 'eval_completion')
                                             and k.measure not in PLANNING_KEYS)
                rec.link_warning = (_('%s KPI(s) read Sales/Purchase/Analytic data, but no analytic account or sales team '
                                      'is set: they will show "No data".') % len(needs)) if needs else False
            if not rec.link_warning and not rec.department_ids and rec.kpi_ids.filtered(
                    lambda k: k.active and k.measure in PLANNING_KEYS):
                rec.link_warning = _('Planning KPIs: no departments are set, so only shifts created from this '
                                     "directorate's annual plans are counted and worked hours show \"No data\".")

    def action_view_pe_shifts(self):
        self.ensure_one()
        action = self.env['pe.plan']._pe_shift_action()
        action['domain'] = list(self._pe_slot_domain())
        action['context'] = {'default_pe_directorate_id': self.id}
        return action


class PeDirectorateKpi(models.Model):
    _inherit = 'pe.directorate.kpi'

    measure = fields.Selection(selection_add=PLANNING_MEASURES,
                               ondelete={key: 'set default' for key in PLANNING_KEYS})

    @api.onchange('measure')
    def _onchange_measure(self):
        super()._onchange_measure()
        if self.measure in PLANNING_RATIO:
            self.calc_type = 'ratio'
