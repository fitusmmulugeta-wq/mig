{
    'name': 'Beaeka Performance Evaluation - Planning',
    'version': '19.0.1.0.0',
    'category': 'Human Resources/Appraisals',
    'summary': 'Planning shifts as directorate KPIs; annual plan staffing creates shifts in Planning',
    'description': 'Bridge between Beaeka Performance Evaluation and Odoo Planning. '
                   '1) New KPI sources: planned hours, worked hours, worked vs planned hours, shifts staffed. '
                   '2) Annual plans get a Staffing table; approving the plan creates the monthly shifts in Planning '
                   'and fills the planned-hours KPI line.',
    'author': 'Beaeka Group ICT',
    'license': 'LGPL-3',
    'depends': ['beaeka_performance_evaluation', 'planning'],
    'data': [
        'security/ir.model.access.csv',
        'views/pe_planning_views.xml',
    ],
    'auto_install': True,
    'installable': True,
}
