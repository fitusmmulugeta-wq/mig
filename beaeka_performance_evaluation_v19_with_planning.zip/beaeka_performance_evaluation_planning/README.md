# Beaeka Performance Evaluation - Planning (Odoo 19)

Bridge between **Beaeka Performance Evaluation** and **Odoo Planning** (Enterprise). Installs automatically when
both are installed. Optional: Attendances (hr_attendance) or Timesheets for worked hours.

## 1. Planning data as directorate KPIs
New values for "Actual comes from" on a directorate KPI:

| Source | Result | Suggested calculation |
|---|---|---|
| Planning: planned hours (published shifts) | hours | Actual ÷ Plan (planned hours in the annual plan) |
| Planning: worked hours (attendance / timesheets) | hours | Actual ÷ Plan |
| Planning: worked ÷ planned hours | % | Ratio (set automatically), target e.g. ≥95% |
| Planning: shifts staffed (assigned ÷ all shifts) | % | Ratio (set automatically), target e.g. 100% |

Shifts counted for a directorate: shifts of employees in its departments + shifts created from its annual plans.
Only published shifts count. Worked hours: directorate setting "Worked hours from" (Automatic = Attendances when
installed, else Timesheets). Partly overlapping shifts are prorated to the scorecard period.

## 2. Annual plan -> shifts in Planning
Annual plan form > Staffing table: role, employee (or empty = open shift), people, time %, from/to month.
- Approve: one shift per person per month is created in Planning (unpublished) and the hours are written into the
  plan lines whose KPI uses "Planning: planned hours".
- Generate Shifts (approved plans): replaces the plan's unpublished shifts, tops up missing ones, keeps published ones.
- Reset to Draft / Cancel: removes unpublished shifts; published ones stay.
- Planners review and publish in Planning; shifts carry Annual plan / Directorate fields for filtering.
- Smart buttons "Shifts" on the annual plan and on the directorate.

## Install
Copy `beaeka_performance_evaluation_planning` next to `beaeka_performance_evaluation` in the addons path, restart,
Apps > Update Apps List > install "Beaeka Performance Evaluation - Planning".
