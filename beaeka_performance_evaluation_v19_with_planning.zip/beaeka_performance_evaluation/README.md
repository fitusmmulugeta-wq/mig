# Beaeka Performance Evaluation (Odoo 19) — v19.0.2.0.1

Install / upgrade: copy the `beaeka_performance_evaluation` folder into your custom addons path, restart Odoo, then
Apps > Update Apps List > "Beaeka Performance Evaluation" > Install (or Upgrade if version 1 is installed).
Depends on hr, mail, account, sale, purchase (Accounting, Sales and Purchase are installed if missing). Python: openpyxl.
Optional: sale_margin (for the gross-margin KPI), purchase_stock (for purchase on-time KPIs).

## Individual evaluations (unchanged workflow)
1. Configuration > Periods & Company BSC: set the current period and rate the company BSC.
2. Organogram > Employee Evaluation Setup: form (A–D), scorecard template, or Excluded.
3. Evaluations > Generate Evaluations. Workflow: Draft > Self Assessment > Manager Review > Calibration > Approved.
4. Inside a perspective, KPIs now share its weight in proportion to their "KPI weight" (equally when blank).

## Directorate & chief-office scorecards (new)
The 23 directorates and 262 KPIs of BEAEKA_Directorate_KPIs_by_Department.xlsx are pre-loaded.

Setup, once per directorate (Configuration > Directorates & Chief Offices):
- Director / Chief (employee with a user), departments, data owners (users in the Supervisor group).
- Analytic accounts (and optionally sales teams): sales order lines, invoices, purchase lines and analytic lines
  carrying them are counted for the directorate. A line split across accounts counts its share.
- Chief offices: level "Chief office"; directorates point to it in "Reports to". Score = own KPIs share + weighted
  average of its directorates. Manufacturing Office is pre-set as chief over the five factories (50% own KPIs).
- Fix weights not totalling 100% (button "Rescale Weights to 100%"), check "Actual comes from" on each KPI.

Planning: Directorate Performance > Annual Plans. One plan per directorate and fiscal year (M01 = first month, default
July). "Load Plan KPIs" adds the KPIs measured against the plan; enter monthly values or an annual value and
"Spread Annual Evenly"; Approve. While a period is still running, actuals are compared with the plan up to today.

Automatic evaluation (the nightly scheduled action "Performance Evaluation: refresh alerts and remind overdue"):
- creates monthly, quarterly and evaluation-period scorecards (Settings > Directorate scorecards),
- reads actuals from Sales, Purchase, Accounting/analytic and HR, applies the plan, scores every KPI
  (green / amber / red) and rolls directorates up to their chief office,
- notifies the director when KPIs go off track; reminds data owners (To-Do) about missing manual KPIs
  a few days before the period ends,
- after the period ends: "Data closing" message; after the grace days the scorecard is closed and frozen and the result
  goes to director, chief and HR administrators; a low score creates a review To-Do for the chief,
- auto-rates system-measured KPIs in individual evaluations (supervisors can override),
- adds directorate alerts to Alerts.
Data owners use Directorate Performance > My KPIs to Enter (actual, or numerator and denominator).

Director's own evaluation: on the directorate, "Create Evaluation Template" builds a template whose KPIs read the
directorate's results (source "Directorate KPI") with the Excel weights, and assigns it to the director.
Source "Directorate scorecard: total score" gives one KPI equal to the whole scorecard score.

Re-import a revised workbook: Configuration > Import KPIs from Excel (matched by directorate + KPI code).
Analysis: Reporting > KPI Analysis; scorecards have pivot/graph views and a printable PDF.

## Odoo 19 notes
Ported from 18.0: SQL constraints use `models.Constraint`, security groups use a privilege (Settings > Users >
Performance Evaluation), domains use `odoo.fields.Domain`, search views and the settings action follow the 19.0 schema.
Behaviour and data are unchanged. Upgrading an 18.0 database: run Odoo's database upgrade first, then update this module.

## 19.0.2.0.1
Fix: Annual Plans > New raised `TypeError: default_fy_start() takes 0 positional arguments but 1 was given`
(Odoo passes the record to field defaults; the default is now wrapped in a lambda).
Planning integration: install the companion module `beaeka_performance_evaluation_planning`.
