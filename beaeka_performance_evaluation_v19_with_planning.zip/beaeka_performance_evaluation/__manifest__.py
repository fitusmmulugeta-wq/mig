{
    'name': 'Beaeka Performance Evaluation',
    'version': '19.0.2.0.1',
    'category': 'Human Resources/Appraisals',
    'summary': 'BSC KPI scorecards, directorate KPIs linked to plans, sales, purchase and analytic accounts, '
               'automatic evaluation and notifications',
    'description': 'Performance evaluation for Beaeka: forms A-D, BSC perspective KPI scorecards, self/supervisor ratings, '
                   'calibration and approval, leadership and engagement surveys, alerts and PDF reports. '
                   'Directorate and chief-office scorecards from the "Integrated PM with BSC" KPI workbook, measured against '
                   'annual plans with actuals from Sales, Purchase and Accounting (analytic), evaluated automatically every night '
                   'with notifications to directors, chiefs, data owners and HR.',
    'author': 'Beaeka Group ICT',
    'license': 'LGPL-3',
    'depends': ['hr', 'mail', 'account', 'sale', 'purchase'],
    'external_dependencies': {'python': ['openpyxl']},
    'data': [
        'security/pe_security.xml',
        'security/ir.model.access.csv',
        'data/pe_sequence.xml',
        'data/pe_data.xml',
        'data/pe_directorate_kpi_data.xml',
        'data/pe_cron.xml',
        'report/pe_reports.xml',
        'report/pe_report_templates.xml',
        'report/pe_scorecard_report.xml',
        'wizard/pe_wizard_views.xml',
        'views/pe_config_views.xml',
        'views/pe_evaluation_views.xml',
        'views/pe_survey_views.xml',
        'views/pe_alert_views.xml',
        'views/hr_views.xml',
        'views/res_config_settings_views.xml',
        'views/pe_menus.xml',
        'views/pe_directorate_views.xml',
    ],
    'application': True,
    'installable': True,
}
