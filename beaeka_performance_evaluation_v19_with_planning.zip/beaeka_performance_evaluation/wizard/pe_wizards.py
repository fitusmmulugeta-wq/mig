import hashlib

from odoo import SUPERUSER_ID, api, fields, models, _
from odoo.exceptions import UserError

from ..models.pe_config import param_str

DEFAULT_QS = {
    'q1': 'Clarity — My leader sets clear goals and expectations for my work',
    'q2': 'Support — My leader provides the support and resources I need to succeed',
    'q3': 'Safety — I feel safe bringing problems, mistakes or tough feedback to my leader',
    'q4': 'Growth — My leader actively supports my career development',
    'q5': 'Loyalty — I would recommend my leader to other colleagues',
    'eng_question': 'How likely are you to recommend working at BEAEKA to a friend or colleague?',
}
FIVE = [(str(i), str(i)) for i in range(5, 0, -1)]
ELEVEN = [(str(i), str(i)) for i in range(0, 11)]


def _response_key(env, *parts):
    secret = env['ir.config_parameter'].sudo().get_param('database.secret', '')
    raw = ':'.join([secret, str(env.uid)] + [str(p) for p in parts])
    return hashlib.sha256(raw.encode()).hexdigest()


class PeGenerateWizard(models.TransientModel):
    _name = 'pe.generate.wizard'
    _description = 'Generate Performance Evaluations'

    period_id = fields.Many2one('pe.period', required=True, default=lambda self: self.env['pe.period'].get_current())
    department_ids = fields.Many2many('hr.department', string='Departments', help='Leave empty for all departments.')
    include_children = fields.Boolean('Include sub-departments', default=True)
    employee_ids = fields.Many2many('hr.employee', string='Only these employees')
    source = fields.Selection([('auto', "Employee's template, else last evaluation, else blank"),
                               ('template', 'A specific template'), ('previous', 'Copy last evaluation'),
                               ('blank', 'Blank scorecard')], default='auto', required=True, string='KPIs from')
    template_id = fields.Many2one('pe.template')
    due_date = fields.Date()

    def action_generate(self):
        self.ensure_one()
        if self.source == 'template' and not self.template_id:
            raise UserError(_('Choose the template to use.'))
        domain = [('pe_excluded', '=', False), ('company_id', 'in', self.env.companies.ids)]
        if self.employee_ids:
            domain.append(('id', 'in', self.employee_ids.ids))
        if self.department_ids:
            op = 'child_of' if self.include_children else 'in'
            domain.append(('department_id', op, self.department_ids.ids))
        employees = self.env['hr.employee'].search(domain)
        existing = self.env['pe.evaluation'].search([('period_id', '=', self.period_id.id),
                                                     ('employee_id', 'in', employees.ids)]).mapped('employee_id')
        todo = employees - existing
        if not todo:
            raise UserError(_('Every selected employee already has an evaluation for %s.') % self.period_id.name)
        Eval = self.env['pe.evaluation'].with_context(pe_source=self.source, pe_template_id=self.template_id.id)
        created = Eval.create([{'employee_id': e.id, 'period_id': self.period_id.id, 'company_id': e.company_id.id,
                                'due_date': self.due_date or self.period_id.due_date} for e in todo])
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_evaluation')
        action['domain'] = [('id', 'in', created.ids)]
        return action


class PeSaveTemplateWizard(models.TransientModel):
    _name = 'pe.save.template.wizard'
    _description = 'Save KPIs as Template'

    evaluation_id = fields.Many2one('pe.evaluation', required=True)
    name = fields.Char('Template name', required=True)
    period_label = fields.Char()

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        ev = self.env['pe.evaluation'].browse(res.get('evaluation_id') or self.env.context.get('active_id'))
        if ev:
            res.update(evaluation_id=ev.id, name=ev.template_name or ev.employee_id.job_title or ev.employee_id.name,
                       period_label=ev.period_id.name)
        return res

    def action_save(self):
        self.ensure_one()
        ev = self.evaluation_id
        Template = self.env['pe.template']
        existing = Template.search([('name', '=ilike', self.name)], limit=1)
        lines = [(0, 0, {f: (line[f].id if isinstance(line[f], models.BaseModel) else line[f])
                         for f in ('sequence', 'perspective_id', 'major_function', 'name', 'baseline', 'target',
                                   'measure', 'frequency', 'evidence', 'initiatives', 'source', 'dir_kpi_id', 'kpi_weight')})
                 for line in ev.kpi_ids if line.name]
        weights = [(0, 0, {'perspective_id': w.perspective_id.id, 'weight': w.weight}) for w in ev.weight_ids]
        vals = {'name': self.name, 'period_label': self.period_label,
                'line_ids': [(5, 0, 0)] + lines, 'weight_ids': [(5, 0, 0)] + weights}
        if existing:
            existing.write(vals)
            template = existing
        else:
            template = Template.create(vals)
        ev.template_name = template.name
        ev.message_post(body=_('KPIs saved as template %s.') % template.name)
        return {'type': 'ir.actions.act_window', 'res_model': 'pe.template', 'res_id': template.id, 'view_mode': 'form'}


class PeLeadershipWizard(models.TransientModel):
    _name = 'pe.leadership.wizard'
    _description = 'Leadership Effectiveness Feedback'

    period_id = fields.Many2one('pe.period', required=True, default=lambda self: self.env['pe.period'].get_current())
    leader_id = fields.Many2one('hr.employee', string='Leader you are rating', required=True,
                                domain="[('child_ids', '!=', False)]")
    q1_label = fields.Char(compute='_compute_labels')
    q2_label = fields.Char(compute='_compute_labels')
    q3_label = fields.Char(compute='_compute_labels')
    q4_label = fields.Char(compute='_compute_labels')
    q5_label = fields.Char(compute='_compute_labels')
    q1 = fields.Selection(FIVE, required=True)
    q2 = fields.Selection(FIVE, required=True)
    q3 = fields.Selection(FIVE, required=True)
    q4 = fields.Selection(FIVE, required=True)
    q5 = fields.Selection(FIVE, required=True)

    def _compute_labels(self):
        for rec in self:
            for q in ('q1', 'q2', 'q3', 'q4', 'q5'):
                rec[q + '_label'] = param_str(self.env, q, DEFAULT_QS[q])

    def action_submit(self):
        self.ensure_one()
        if self.leader_id.user_id == self.env.user:
            raise UserError(_('You cannot rate yourself.'))
        key = _response_key(self.env, 'lead', self.period_id.id, self.leader_id.id)
        Resp = self.env['pe.leadership.response'].with_user(SUPERUSER_ID)
        if Resp.search_count([('response_key', '=', key)]):
            raise UserError(_('You have already rated %s for this period.') % self.leader_id.name)
        Resp.create({'period_id': self.period_id.id, 'leader_id': self.leader_id.id, 'response_key': key,
                     **{q: int(self[q]) for q in ('q1', 'q2', 'q3', 'q4', 'q5')}})
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'title': _('Thank you'), 'message': _('Your feedback was recorded without your name.'),
                           'type': 'success', 'next': {'type': 'ir.actions.act_window_close'}}}


class PeEngagementWizard(models.TransientModel):
    _name = 'pe.engagement.wizard'
    _description = 'Employee Engagement Survey'

    period_id = fields.Many2one('pe.period', required=True, default=lambda self: self.env['pe.period'].get_current())
    question = fields.Char(compute='_compute_question')
    score = fields.Selection(ELEVEN, required=True)
    department_id = fields.Many2one('hr.department', string='Your unit (optional)')

    def _compute_question(self):
        for rec in self:
            rec.question = param_str(self.env, 'eng_question', DEFAULT_QS['eng_question'])

    def action_submit(self):
        self.ensure_one()
        key = _response_key(self.env, 'eng', self.period_id.id)
        Resp = self.env['pe.engagement.response'].with_user(SUPERUSER_ID)
        if Resp.search_count([('response_key', '=', key)]):
            raise UserError(_('You have already answered the engagement survey for this period.'))
        Resp.create({'period_id': self.period_id.id, 'department_id': self.department_id.id, 'score': int(self.score),
                     'response_key': key, 'company_id': self.env.company.id})
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'title': _('Thank you'), 'message': _('Your answer was recorded without your name.'),
                           'type': 'success', 'next': {'type': 'ir.actions.act_window_close'}}}
