import base64

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from ..models.pe_kpi_excel import read_rows
from ..models.pe_scorecard import SCOPES, scope_range

PERSPECTIVE_REFS = {'fin': 'persp_fin', 'cus': 'persp_cus', 'int': 'persp_int', 'lnd': 'persp_lnd'}
KEEP_ON_UPDATE = ('measure', 'calc_type', 'owner_user_id')


class PeKpiImportWizard(models.TransientModel):
    _name = 'pe.kpi.import.wizard'
    _description = 'Import Directorate KPIs from Excel'

    file = fields.Binary('KPI workbook', required=True)
    filename = fields.Char()
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    create_directorates = fields.Boolean('Create missing directorates', default=True)
    keep_settings = fields.Boolean('Keep data-source settings of existing KPIs', default=True,
                                   help='Do not overwrite "Actual comes from" and "Calculation" that were adjusted in Odoo.')
    archive_missing = fields.Boolean('Archive KPIs no longer in the workbook')
    result = fields.Text(readonly=True)

    def _perspective(self, key):
        ref = PERSPECTIVE_REFS.get(key)
        rec = self.env.ref('beaeka_performance_evaluation.%s' % ref, raise_if_not_found=False) if ref else None
        return rec or self.env['pe.perspective'].search([], limit=1)

    def action_import(self):
        self.ensure_one()
        try:
            rows = list(read_rows(base64.b64decode(self.file)))
        except Exception as exc:  # openpyxl raises many kinds of errors on bad files
            raise UserError(_('The file could not be read as an Excel workbook: %s') % exc) from exc
        if not rows:
            raise UserError(_('No KPI rows found. The sheet needs a header row with "KPI Code" and "KPI Name".'))
        Dir = self.env['pe.directorate'].with_context(active_test=False)
        Kpi = self.env['pe.directorate.kpi'].with_context(active_test=False)
        created_dirs = created = updated = 0
        seen = Kpi.browse()
        notes = []
        for seq, (dir_name, vals) in enumerate(rows, start=1):
            directorate = Dir.search([('name', '=ilike', dir_name), ('company_id', '=', self.company_id.id)], limit=1)
            if not directorate:
                if not self.create_directorates:
                    notes.append(_('Skipped %(c)s: directorate "%(d)s" not found.', c=vals['code'], d=dir_name))
                    continue
                directorate = Dir.create({'name': dir_name, 'company_id': self.company_id.id,
                                          'code': vals['code'].split('-')[0] if '-' in vals['code'] else False})
                created_dirs += 1
            persp = self._perspective(vals.pop('perspective'))
            vals.update(perspective_id=persp.id, sequence=seq, active=True)
            kpi = Kpi.search([('directorate_id', '=', directorate.id), ('code', '=', vals['code'])], limit=1)
            if kpi:
                if self.keep_settings:
                    for key in KEEP_ON_UPDATE:
                        vals.pop(key, None)
                kpi.write(vals)
                updated += 1
            else:
                kpi = Kpi.create(dict(vals, directorate_id=directorate.id))
                created += 1
            seen |= kpi
            if vals.get('import_note'):
                notes.append('%s / %s: %s' % (directorate.name, vals['code'], vals['import_note']))
        touched = seen.mapped('directorate_id')
        archived = 0
        if self.archive_missing:
            stale = Kpi.search([('directorate_id', 'in', touched.ids), ('id', 'not in', seen.ids), ('active', '=', True)])
            archived = len(stale)
            stale.write({'active': False})
        for directorate in touched:
            if not directorate.weight_ok:
                notes.append(_('%(d)s: weights total %(w).1f%% (use "Rescale weights to 100%%" on the directorate).',
                               d=directorate.name, w=directorate.weight_total))
        summary = _('%(k)s KPI rows read: %(c)s created, %(u)s updated, %(a)s archived; %(d)s directorates created.',
                    k=len(rows), c=created, u=updated, a=archived, d=created_dirs)
        self.result = '\n'.join([summary] + notes)
        return {'type': 'ir.actions.act_window', 'res_model': self._name, 'res_id': self.id, 'view_mode': 'form',
                'target': 'new', 'context': {'pe_import_done': True}}

    def action_open_kpis(self):
        return self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_directorate_kpi')


class PeScorecardGenerateWizard(models.TransientModel):
    _name = 'pe.scorecard.generate.wizard'
    _description = 'Generate Directorate Scorecards'

    directorate_ids = fields.Many2many('pe.directorate', string='Directorates', help='Leave empty for all.')
    scope = fields.Selection(SCOPES, required=True, default='month')
    reference_date = fields.Date('Any date in the period', default=fields.Date.context_today)
    period_id = fields.Many2one('pe.period', string='Evaluation period', default=lambda self: self.env['pe.period'].get_current())
    date_from = fields.Date(compute='_compute_dates', store=True, readonly=False)
    date_to = fields.Date(compute='_compute_dates', store=True, readonly=False)

    @api.depends('scope', 'reference_date', 'period_id')
    def _compute_dates(self):
        for rec in self:
            if rec.scope != 'custom':
                rec.date_from, rec.date_to = scope_range(rec.scope, rec.reference_date, rec.period_id)

    def action_generate(self):
        self.ensure_one()
        if not self.date_from or not self.date_to:
            raise UserError(_('Choose the dates (an evaluation period needs its start and end dates).'))
        directorates = self.directorate_ids or self.env['pe.directorate'].search([])
        Card = self.env['pe.scorecard']
        cards = Card.browse()
        for directorate in directorates:
            card = Card.search([('directorate_id', '=', directorate.id), ('date_from', '=', self.date_from),
                                ('date_to', '=', self.date_to)], limit=1)
            if not card:
                card = Card.create({'directorate_id': directorate.id, 'scope': self.scope, 'date_from': self.date_from,
                                    'date_to': self.date_to,
                                    'period_id': self.period_id.id if self.scope == 'period' else False})
            cards |= card
        cards.action_compute(notify=False)
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_scorecard')
        action['domain'] = [('id', 'in', cards.ids)]
        action['context'] = {}
        return action
