from odoo import api, models

from ..models.pe_config import param_float


class ReportPeriodSummary(models.AbstractModel):
    _name = 'report.beaeka_performance_evaluation.report_period_summary'
    _description = 'Performance Evaluation Period Summary'

    @api.model
    def _get_report_values(self, docids, data=None):
        periods = self.env['pe.period'].browse(docids)
        bands = self.env['pe.score.band'].search([], order='min_score desc')
        min_n = int(param_float(self.env, 'min_responses', 3))
        summaries = {}
        for period in periods:
            evals = self.env['pe.evaluation'].search([('period_id', '=', period.id)])
            emps = self.env['hr.employee'].search([('pe_excluded', '=', False)])
            rows = []
            for dep in emps.mapped('department_id').sorted('complete_name'):
                dep_emps = emps.filtered(lambda e, d=dep: e.department_id == d)
                dep_evals = evals.filtered(lambda e, d=dep: e.department_id == d)
                done = dep_evals.filtered(lambda e: e.state == 'done')
                rows.append({
                    'name': dep.complete_name, 'hc': len(dep_emps), 'started': len(dep_evals), 'done': len(done),
                    'avg': sum(done.mapped('total_score')) / len(done) if done else None,
                    'dist': [len(done.filtered(lambda e, b=b: e.band_id == b)) for b in bands],
                })
            done = evals.filtered(lambda e: e.state == 'done')
            leaders = emps.filtered('child_ids')
            lead_rows = []
            for leader in leaders:
                st = self.env['pe.leadership.response'].stats(period, leader)
                if st['n'] >= min_n:
                    lead_rows.append({'leader': leader, **st})
            summaries[period.id] = {
                'rows': rows,
                'total': {'hc': len(emps), 'started': len(evals), 'done': len(done),
                          'avg': sum(done.mapped('total_score')) / len(done) if done else None,
                          'dist': [len(done.filtered(lambda e, b=b: e.band_id == b)) for b in bands]},
                'ranked': done.sorted('total_score', reverse=True),
                'alerts': self.env['pe.alert'].search([('period_id', '=', period.id), ('severity', '!=', 'info')]),
                'lead_rows': lead_rows,
                'lead_all': self.env['pe.leadership.response'].stats(period),
                'eng': self.env['pe.engagement.response'].stats(period),
            }
        return {'doc_ids': docids, 'doc_model': 'pe.period', 'docs': periods, 'bands': bands,
                'summaries': summaries, 'min_n': min_n}
