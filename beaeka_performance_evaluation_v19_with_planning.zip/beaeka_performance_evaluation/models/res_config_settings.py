from odoo import api, fields, models

DEFAULT_ON = ['auto_rate', 'dir_auto_month', 'dir_auto_quarter', 'dir_auto_period', 'dir_notify_admins']


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    pe_due_days = fields.Integer('Due-soon window (days)', default=7, config_parameter='beaeka_pe.due_days')
    pe_low_score = fields.Float('Expectation line (score %)', default=60, config_parameter='beaeka_pe.low_score')
    pe_pip_score = fields.Float('Improvement-plan line (score %)', default=50, config_parameter='beaeka_pe.pip_score')
    pe_kpi_gap = fields.Float('KPI gap (% of target)', default=80, config_parameter='beaeka_pe.kpi_gap')
    pe_lead_min = fields.Float('Leadership minimum (of 5)', default=3, config_parameter='beaeka_pe.lead_min')
    pe_ach_5 = fields.Float('Rating 5 from achievement %', default=110, config_parameter='beaeka_pe.ach_5')
    pe_ach_4 = fields.Float('Rating 4 from achievement %', default=100, config_parameter='beaeka_pe.ach_4')
    pe_ach_3 = fields.Float('Rating 3 from achievement %', default=90, config_parameter='beaeka_pe.ach_3')
    pe_ach_2 = fields.Float('Rating 2 from achievement %', default=75, config_parameter='beaeka_pe.ach_2')
    pe_min_responses = fields.Integer('Minimum responses to show results', default=3, config_parameter='beaeka_pe.min_responses')
    pe_passives_positive = fields.Boolean('Count passives (7-8) as positive', config_parameter='beaeka_pe.passives_positive')
    pe_q1 = fields.Char('Leadership statement 1', config_parameter='beaeka_pe.q1')
    pe_q2 = fields.Char('Leadership statement 2', config_parameter='beaeka_pe.q2')
    pe_q3 = fields.Char('Leadership statement 3', config_parameter='beaeka_pe.q3')
    pe_q4 = fields.Char('Leadership statement 4', config_parameter='beaeka_pe.q4')
    pe_q5 = fields.Char('Leadership statement 5', config_parameter='beaeka_pe.q5')
    pe_eng_question = fields.Char('Engagement question', config_parameter='beaeka_pe.eng_question')
    pe_auto_rate = fields.Boolean('Auto-rate system KPIs', config_parameter='beaeka_pe.auto_rate',
                                  help='Supervisor rating of KPIs measured by the system is filled from the achievement; '
                                       'the supervisor can still change it.')
    pe_dir_green = fields.Float('On track from (achievement %)', default=95, config_parameter='beaeka_pe.dir_green')
    pe_dir_amber = fields.Float('At risk from (achievement %)', default=80, config_parameter='beaeka_pe.dir_amber')
    pe_dir_cap = fields.Float('Achievement cap %', default=120, config_parameter='beaeka_pe.dir_cap')
    pe_dir_grace_days = fields.Integer('Days to enter data after period end', default=10, config_parameter='beaeka_pe.dir_grace_days')
    pe_dir_reminder_days = fields.Integer('Remind data owners (days before end)', default=5,
                                         config_parameter='beaeka_pe.dir_reminder_days')
    pe_dir_auto_month = fields.Boolean('Monthly scorecards', config_parameter='beaeka_pe.dir_auto_month')
    pe_dir_auto_quarter = fields.Boolean('Quarterly scorecards', config_parameter='beaeka_pe.dir_auto_quarter')
    pe_dir_auto_period = fields.Boolean('Evaluation-period scorecards', config_parameter='beaeka_pe.dir_auto_period')
    pe_dir_auto_year = fields.Boolean('Fiscal-year scorecards', config_parameter='beaeka_pe.dir_auto_year')
    pe_dir_notify_admins = fields.Boolean('Send closing results to administrators', config_parameter='beaeka_pe.dir_notify_admins')

    @api.model
    def get_values(self):
        res = super().get_values()
        if not self.env['ir.config_parameter'].sudo().get_param('beaeka_pe.settings_saved'):
            res.update({'pe_' + key: True for key in DEFAULT_ON})
        return res

    def set_values(self):
        super().set_values()
        self.env['ir.config_parameter'].sudo().set_param('beaeka_pe.settings_saved', '1')
