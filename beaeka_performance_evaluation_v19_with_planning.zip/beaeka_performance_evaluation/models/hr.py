from odoo import api, fields, models


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    pe_form_type_id = fields.Many2one('pe.form.type', string='Evaluation form')
    pe_template_id = fields.Many2one('pe.template', string='KPI scorecard template')
    pe_excluded = fields.Boolean('Excluded from evaluation',
                                 help='Not expected to have a performance evaluation (e.g. on probation or leave).')
    pe_evaluation_ids = fields.One2many('pe.evaluation', 'employee_id')
    pe_evaluation_count = fields.Integer(compute='_compute_pe_stats')
    pe_last_score = fields.Float('Last evaluation score %', compute='_compute_pe_stats')
    pe_directorate_id = fields.Many2one('pe.directorate', string='Directorate', compute='_compute_pe_directorate',
                                        help='The directorate this employee heads, else the one owning their department.')

    def _compute_pe_directorate(self):
        Dir = self.env['pe.directorate']
        for emp in self:
            emp.pe_directorate_id = Dir.for_employee(emp) if emp.id else Dir

    def _compute_pe_stats(self):
        for emp in self:
            evals = emp.pe_evaluation_ids
            emp.pe_evaluation_count = len(evals)
            done = evals.filtered(lambda e: e.state == 'done').sorted('approved_date', reverse=True)
            emp.pe_last_score = done[:1].total_score if done else 0.0

    def action_view_pe_evaluations(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_evaluation')
        action['domain'] = [('employee_id', '=', self.id)]
        action['context'] = {'default_employee_id': self.id}
        return action


class HrDepartment(models.Model):
    _inherit = 'hr.department'

    pe_headcount = fields.Integer('In scope', compute='_compute_pe_stats')
    pe_started = fields.Integer('Started', compute='_compute_pe_stats')
    pe_done = fields.Integer('Approved', compute='_compute_pe_stats')
    pe_completion = fields.Float('Completion %', compute='_compute_pe_stats')
    pe_avg_score = fields.Float('Average score %', compute='_compute_pe_stats')

    def _compute_pe_stats(self):
        period = self.env['pe.period'].get_current()
        Emp = self.env['hr.employee'].sudo()
        Eval = self.env['pe.evaluation'].sudo()
        for dep in self:
            emps = Emp.search([('department_id', '=', dep.id), ('pe_excluded', '=', False)])
            evals = Eval.search([('department_id', '=', dep.id), ('period_id', '=', period.id)]) if period else Eval
            done = evals.filtered(lambda e: e.state == 'done')
            dep.pe_headcount = len(emps)
            dep.pe_started = len(evals)
            dep.pe_done = len(done)
            dep.pe_completion = len(done) / len(emps) * 100 if emps else 0.0
            dep.pe_avg_score = sum(done.mapped('total_score')) / len(done) if done else 0.0
