import calendar
from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, _
from odoo.exceptions import UserError

MONTH_FIELDS = ['m%02d' % i for i in range(1, 13)]


def default_fy_start():
    today = date.today()
    # Ethiopian fiscal year: Hamle (July) to Sene (June)
    year = today.year if today.month >= 7 else today.year - 1
    return date(year, 7, 1)


class PePlan(models.Model):
    _name = 'pe.plan'
    _inherit = ['mail.thread']
    _description = 'Directorate Annual Plan'
    _order = 'date_start desc, directorate_id'

    name = fields.Char(compute='_compute_name', store=True)
    directorate_id = fields.Many2one('pe.directorate', required=True, tracking=True, index=True)
    company_id = fields.Many2one(related='directorate_id.company_id', store=True)
    currency_id = fields.Many2one(related='directorate_id.currency_id')
    fiscal_year = fields.Char('Fiscal year', help='Label only, e.g. "EFY 2019 (2026/27)".')
    date_start = fields.Date('First month', required=True, default=lambda self: default_fy_start(),
                             help='M01 is this month; the plan covers 12 months.')
    date_end = fields.Date(compute='_compute_date_end', store=True)
    state = fields.Selection([('draft', 'Draft'), ('approved', 'Approved'), ('cancel', 'Cancelled')], default='draft',
                             required=True, tracking=True)
    line_ids = fields.One2many('pe.plan.line', 'plan_id', string='Planned values', copy=True)
    month_labels = fields.Char(compute='_compute_month_labels')
    note = fields.Text()

    _directorate_start_uniq = models.Constraint(
        'unique(directorate_id, date_start)',
        'This directorate already has a plan starting that month.',
    )
    @api.depends('directorate_id', 'fiscal_year', 'date_start')
    def _compute_name(self):
        for rec in self:
            label = rec.fiscal_year or (rec.date_start and rec.date_start.strftime('%b %Y')) or ''
            rec.name = '%s — %s' % (rec.directorate_id.name or '', label)

    @api.depends('date_start')
    def _compute_date_end(self):
        for rec in self:
            start = rec.date_start and rec.date_start.replace(day=1)
            rec.date_end = start + relativedelta(months=12, days=-1) if start else False

    @api.depends('date_start')
    def _compute_month_labels(self):
        for rec in self:
            start = rec.date_start and rec.date_start.replace(day=1)
            rec.month_labels = ' · '.join('M%02d %s' % (i + 1, (start + relativedelta(months=i)).strftime('%b'))
                                          for i in range(12)) if start else False

    @api.onchange('date_start')
    def _onchange_date_start(self):
        if self.date_start and self.date_start.day != 1:
            self.date_start = self.date_start.replace(day=1)

    def action_load_kpis(self):
        for rec in self:
            have = rec.line_ids.mapped('kpi_id')
            kpis = rec.directorate_id.kpi_ids.filtered(
                lambda k: k.active and k not in have and (k.calc_type in ('plan', 'plan_inv', 'variance')
                                                          or (k.calc_type == 'value' and not k.has_target)))
            rec.line_ids = [(0, 0, {'kpi_id': k.id, 'sequence': k.sequence}) for k in kpis]

    def action_spread(self):
        self.mapped('line_ids').action_spread()

    def action_approve(self):
        for rec in self:
            if not rec.line_ids:
                raise UserError(_('Add the planned values first (Load plan KPIs).'))
            rec.state = 'approved'
        self.env['pe.scorecard'].sudo().search([('directorate_id', 'in', self.directorate_id.ids),
                                                ('state', '!=', 'done')]).action_compute(notify=False)

    def action_draft(self):
        self.write({'state': 'draft'})

    def action_cancel(self):
        self.write({'state': 'cancel'})


class PePlanLine(models.Model):
    _name = 'pe.plan.line'
    _description = 'Directorate Plan Line'
    _order = 'sequence, id'

    plan_id = fields.Many2one('pe.plan', required=True, ondelete='cascade', index=True)
    directorate_id = fields.Many2one(related='plan_id.directorate_id', store=True)
    sequence = fields.Integer(default=10)
    kpi_id = fields.Many2one('pe.directorate.kpi', string='KPI', required=True,
                             domain="[('directorate_id', '=', directorate_id)]")
    code = fields.Char(related='kpi_id.code')
    unit = fields.Char(related='kpi_id.unit')
    calc_type = fields.Selection(related='kpi_id.calc_type')
    annual_amount = fields.Float('Annual plan', help='Used evenly over the year when the months are left at zero.')
    m01 = fields.Float('M01')
    m02 = fields.Float('M02')
    m03 = fields.Float('M03')
    m04 = fields.Float('M04')
    m05 = fields.Float('M05')
    m06 = fields.Float('M06')
    m07 = fields.Float('M07')
    m08 = fields.Float('M08')
    m09 = fields.Float('M09')
    m10 = fields.Float('M10')
    m11 = fields.Float('M11')
    m12 = fields.Float('M12')
    month_total = fields.Float('Months total', compute='_compute_month_total')
    is_average = fields.Boolean('Average, not sum', help='For rates and per-employee values: a period uses the average of its '
                                                         'months instead of their sum.')

    _kpi_uniq = models.Constraint(
        'unique(plan_id, kpi_id)',
        'A KPI can appear only once in a plan.',
    )
    @api.depends(*MONTH_FIELDS)
    def _compute_month_total(self):
        for rec in self:
            rec.month_total = sum(rec[f] for f in MONTH_FIELDS)

    @api.onchange('kpi_id')
    def _onchange_kpi(self):
        if self.kpi_id and self.kpi_id.calc_type == 'value':
            self.is_average = True

    def action_spread(self):
        for rec in self:
            if rec.annual_amount:
                each = rec.annual_amount if rec.is_average else rec.annual_amount / 12.0
                rec.write({f: round(each, 2) for f in MONTH_FIELDS})

    def monthly(self):
        self.ensure_one()
        values = [self[f] for f in MONTH_FIELDS]
        if not any(values):
            each = self.annual_amount if self.is_average else self.annual_amount / 12.0
            values = [each] * 12
        return values

    def amount_for(self, date_from, date_to):
        """Planned value for a date range: months prorated by the days they overlap."""
        self.ensure_one()
        start = self.plan_id.date_start.replace(day=1)
        total = weight = 0.0
        for i, value in enumerate(self.monthly()):
            m_start = start + relativedelta(months=i)
            days = calendar.monthrange(m_start.year, m_start.month)[1]
            m_end = m_start + relativedelta(days=days - 1)
            lo, hi = max(m_start, date_from), min(m_end, date_to)
            if lo > hi:
                continue
            frac = ((hi - lo).days + 1) / days
            total += value * frac
            weight += frac
        if self.is_average:
            return total / weight if weight else 0.0
        return total
