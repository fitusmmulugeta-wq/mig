from odoo import api, fields, models, _
from odoo.exceptions import UserError

from .pe_config import FREQUENCY, SOURCE, LINE_FIELDS, line_vals, parse_target, to_number, param_bool, param_float

DIR_SOURCES = ('dir_kpi', 'dir_score')

STATES = [
    ('draft', 'Draft'),
    ('self', 'Self Assessment'),
    ('manager', 'Manager Review'),
    ('calib', 'Calibration'),
    ('done', 'Approved'),
]
RECOMMENDATION = [
    ('none', 'No action'),
    ('merit', 'Merit increment'),
    ('promotion', 'Promotion'),
    ('training', 'Training'),
    ('pip', 'Performance improvement plan'),
    ('transfer', 'Transfer / role change'),
]


class PeEvaluation(models.Model):
    _name = 'pe.evaluation'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Performance Evaluation'
    _order = 'id desc'

    name = fields.Char('Reference', default=lambda self: _('New'), readonly=True, copy=False)
    employee_id = fields.Many2one('hr.employee', required=True, tracking=True, index=True,
                                  domain="[('pe_excluded', '=', False)]")
    department_id = fields.Many2one('hr.department', related='employee_id.department_id', store=True)
    job_title = fields.Char(related='employee_id.job_title')
    manager_id = fields.Many2one('hr.employee', related='employee_id.parent_id', store=True, string='Supervisor')
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    period_id = fields.Many2one('pe.period', required=True, tracking=True, index=True,
                                default=lambda self: self.env['pe.period'].get_current())
    form_type_id = fields.Many2one('pe.form.type', string='Evaluation form', compute='_compute_form_type',
                                   store=True, readonly=False, required=True, tracking=True)
    template_name = fields.Char('Scorecard', readonly=True)
    state = fields.Selection(STATES, default='draft', required=True, tracking=True, group_expand='_group_expand_states')
    due_date = fields.Date(tracking=True)
    approved_date = fields.Date(readonly=True, copy=False)

    weight_ids = fields.One2many('pe.evaluation.weight', 'evaluation_id', string='Perspective weights', copy=True)
    kpi_ids = fields.One2many('pe.evaluation.kpi', 'evaluation_id', string='Individual KPIs', copy=True)
    competency_ids = fields.One2many('pe.evaluation.competency', 'evaluation_id', string='Competencies', copy=True)
    bsc_line_ids = fields.One2many(related='period_id.bsc_line_ids', string='Company BSC')

    company_score = fields.Float('Company BSC %', compute='_compute_scores', store=True, aggregator='avg')
    kpi_score = fields.Float('Individual KPI %', compute='_compute_scores', store=True, aggregator='avg')
    competency_score = fields.Float('Competency %', compute='_compute_scores', store=True, aggregator='avg')
    total_score = fields.Float('Total score %', compute='_compute_scores', store=True, aggregator='avg', tracking=True)
    band_id = fields.Many2one('pe.score.band', string='Rating band', compute='_compute_scores', store=True)
    kpi_weight_total = fields.Float(compute='_compute_scores', store=True, aggregator=None)
    perspective_weight_total = fields.Float(compute='_compute_scores', store=True, aggregator=None)
    competency_weight_total = fields.Float(compute='_compute_scores', store=True, aggregator=None)
    kpi_rated = fields.Integer(compute='_compute_scores', store=True, aggregator=None)
    competency_rated = fields.Integer(compute='_compute_scores', store=True, aggregator=None)
    is_complete = fields.Boolean(compute='_compute_scores', store=True)
    bsc_ok = fields.Boolean(compute='_compute_scores', store=True)
    bsc_frozen = fields.Boolean(readonly=True, copy=False)
    frozen_bsc = fields.Float(readonly=True, copy=False)
    weight_warning = fields.Text(compute='_compute_weight_warning')
    is_overdue = fields.Boolean(compute='_compute_is_overdue')

    employee_comment = fields.Text()
    manager_comment = fields.Text('Supervisor comment')
    development_plan = fields.Text('Development plan / training needs')
    hr_comment = fields.Text('HR / calibration notes')
    recommendation = fields.Selection(RECOMMENDATION, tracking=True)

    # ------------------------------------------------------------------ compute
    @api.depends('employee_id')
    def _compute_form_type(self):
        default = self.env['pe.form.type'].search([('code', '=', 'C')], limit=1)
        for rec in self:
            if not rec.form_type_id or rec.state == 'draft':
                rec.form_type_id = rec.employee_id.sudo().pe_form_type_id or rec.form_type_id or default

    def _group_expand_states(self, states, domain):
        return [key for key, _label in STATES]

    def _kpi_line_weights(self):
        """Each perspective weight is shared by its KPIs: in proportion to their KPI weight when set, else equally."""
        self.ensure_one()
        pw = {w.perspective_id.id: w.weight for w in self.weight_ids}
        groups = {}
        for line in self.kpi_ids:
            groups.setdefault(line.perspective_id.id, self.env['pe.evaluation.kpi'])
            groups[line.perspective_id.id] |= line
        res = {}
        for pid, lines in groups.items():
            total = sum(lines.mapped('kpi_weight'))
            for line in lines:
                share = (line.kpi_weight / total) if total else 1.0 / len(lines)
                res[line] = pw.get(pid, 0.0) * share
        return res

    @api.depends('kpi_ids.rating_id', 'kpi_ids.perspective_id', 'weight_ids.weight', 'weight_ids.perspective_id',
                 'kpi_ids.kpi_weight', 'competency_ids.weight', 'competency_ids.rating_id', 'form_type_id.company_weight',
                 'form_type_id.individual_weight', 'form_type_id.competency_weight',
                 'period_id.bsc_line_ids.weight', 'period_id.bsc_line_ids.rating_id', 'bsc_frozen', 'frozen_bsc')
    def _compute_scores(self):
        maxv = self.env['pe.rating'].max_value()
        Band = self.env['pe.score.band']
        for rec in self:
            lw = rec._kpi_line_weights()
            num = den = 0.0
            for line, w in lw.items():
                if line.rating_id:
                    den += w
                    num += w * line.rating_id.value / maxv
            kpi = num / den * 100 if den else 0.0
            cnum = cden = 0.0
            for line in rec.competency_ids:
                if line.rating_id:
                    cden += line.weight
                    cnum += line.weight * line.rating_id.value / maxv
            comp = cnum / cden * 100 if cden else 0.0
            ft = rec.form_type_id
            if rec.bsc_frozen:
                bsc, bsc_ok = rec.frozen_bsc, True
            else:
                bsc, bsc_ok = rec.period_id.bsc_score, rec.period_id.bsc_rated
            if not ft.company_weight:
                bsc_ok = True
            tw = (ft.company_weight + ft.individual_weight + ft.competency_weight) or 100.0
            total = (ft.company_weight * bsc + ft.individual_weight * kpi + ft.competency_weight * comp) / tw
            rec.kpi_score = kpi
            rec.competency_score = comp
            rec.company_score = bsc
            rec.total_score = total
            rec.band_id = Band.band_for(total) if (den or cden) else False
            rec.kpi_weight_total = sum(lw.values())
            rec.perspective_weight_total = sum(rec.weight_ids.mapped('weight'))
            rec.competency_weight_total = sum(rec.competency_ids.mapped('weight'))
            rec.kpi_rated = len(rec.kpi_ids.filtered('rating_id'))
            rec.competency_rated = len(rec.competency_ids.filtered('rating_id'))
            rec.is_complete = bool(rec.kpi_ids) and all(rec.kpi_ids.mapped('rating_id')) and all(rec.competency_ids.mapped('rating_id'))
            rec.bsc_ok = bsc_ok

    @api.depends('kpi_weight_total', 'perspective_weight_total', 'competency_weight_total', 'bsc_ok', 'kpi_ids.perspective_id', 'weight_ids.weight')
    def _compute_weight_warning(self):
        for rec in self:
            msgs = []
            if abs(rec.perspective_weight_total - 100) > 0.01:
                msgs.append(_('Perspective weights total %.1f%%; they must total 100%%.') % rec.perspective_weight_total)
            for w in rec.weight_ids:
                if w.weight and not rec.kpi_ids.filtered(lambda l, p=w.perspective_id: l.perspective_id == p):
                    msgs.append(_('%(p)s carries %(w).1f%% but has no KPI.', p=w.perspective_id.name, w=w.weight))
            if rec.competency_ids and abs(rec.competency_weight_total - 100) > 0.01:
                msgs.append(_('Competency weights total %.1f%%; they must total 100%%.') % rec.competency_weight_total)
            if not rec.bsc_ok:
                msgs.append(_('The company BSC for this period is not rated yet, so its share counts as 0%.'))
            rec.weight_warning = '\n'.join(msgs) or False

    @api.depends('due_date', 'state')
    def _compute_is_overdue(self):
        today = fields.Date.context_today(self)
        for rec in self:
            rec.is_overdue = bool(rec.due_date and rec.state != 'done' and rec.due_date < today)

    # ------------------------------------------------------------------ create / load
    @api.model_create_multi
    def create(self, vals_list):
        default_form = self.env['pe.form.type'].search([('code', '=', 'C')], limit=1)
        for vals in vals_list:
            if not vals.get('form_type_id') and vals.get('employee_id'):
                emp = self.env['hr.employee'].sudo().browse(vals['employee_id'])
                vals['form_type_id'] = (emp.pe_form_type_id or default_form).id
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('pe.evaluation') or _('New')
        recs = super().create(vals_list)
        source = self.env.context.get('pe_source', 'auto')
        template_id = self.env.context.get('pe_template_id')
        for rec in recs:
            if not rec.kpi_ids:
                rec._load_kpis(source, template_id)
            if not rec.competency_ids:
                rec._load_competencies()
            rec._ensure_weights()
            if not rec.due_date and rec.period_id.due_date:
                rec.due_date = rec.period_id.due_date
        return recs

    def _ensure_weights(self):
        persps = self.env['pe.perspective'].search([])
        for rec in self:
            missing = persps - rec.weight_ids.mapped('perspective_id')
            if missing:
                rec.weight_ids = [(0, 0, {'perspective_id': p.id, 'weight': 0.0}) for p in missing]

    def _load_competencies(self):
        comps = self.env['pe.competency'].search([])
        for rec in self:
            rec.competency_ids = [(5, 0, 0)] + [(0, 0, {'name': c.name, 'weight': c.weight, 'sequence': c.sequence}) for c in comps]

    def _load_kpis(self, how='auto', template_id=False):
        self.ensure_one()
        employee = self.employee_id
        template = self.env['pe.template'].browse(template_id) if template_id else employee.sudo().pe_template_id
        previous = self.search([('employee_id', '=', employee.id), ('id', '!=', self.id), ('kpi_ids', '!=', False)],
                               order='create_date desc', limit=1)
        if how == 'auto':
            how = 'template' if template else ('previous' if previous else 'blank')
        if how == 'template' and not template:
            raise UserError(_('No scorecard template is set for %s.') % employee.name)
        if how == 'previous' and not previous:
            how = 'blank'
        persps = self.env['pe.perspective'].search([])
        if how == 'template':
            lines = [line_vals(line) for line in template.line_ids]
            weights = {w.perspective_id.id: w.weight for w in template.weight_ids}
            name, note = template.name, _('KPIs loaded from template %s') % template.name
        elif how == 'previous':
            lines = [line_vals(line) for line in previous.kpi_ids]
            weights = {w.perspective_id.id: w.weight for w in previous.weight_ids}
            name, note = previous.template_name, _('KPIs copied from %s') % previous.name
        else:
            lines = [{'perspective_id': p.id, 'sequence': p.sequence, 'name': False, 'source': 'manual'} for p in persps]
            weights = {p.id: p.default_weight for p in persps}
            name, note = False, _('Blank scorecard created')
        self.write({
            'kpi_ids': [(5, 0, 0)] + [(0, 0, v) for v in lines],
            'weight_ids': [(5, 0, 0)] + [(0, 0, {'perspective_id': p.id, 'weight': weights.get(p.id, 0.0)}) for p in persps],
            'template_name': name,
        })
        self.message_post(body=note)

    # ------------------------------------------------------------------ workflow
    def _check_weights(self):
        for rec in self:
            if abs(rec.kpi_weight_total - 100) > 0.01 or abs(rec.perspective_weight_total - 100) > 0.01:
                raise UserError(_('%s: perspective weights must total 100%% and every weighted perspective needs at least one KPI.') % rec.name)
            if rec.competency_ids and abs(rec.competency_weight_total - 100) > 0.01:
                raise UserError(_('%s: competency weights must total 100%%.') % rec.name)

    def _move(self, state, note):
        for rec in self:
            rec.state = state
            rec.message_post(body=note)

    def action_to_self(self):
        for rec in self.filtered(lambda r: r.state == 'draft'):
            if rec.kpi_ids.filtered(lambda l: not l.name):
                raise UserError(_('%s: every KPI line needs a KPI description before it goes to the employee.') % rec.name)
            rec._check_weights()
            rec._move('self', _('Sent to the employee for self assessment.'))
            if rec.employee_id.user_id:
                rec.activity_schedule('mail.mail_activity_data_todo', date_deadline=rec.due_date,
                                      user_id=rec.employee_id.user_id.id, summary=_('Complete your self assessment'))

    def action_to_manager(self):
        for rec in self.filtered(lambda r: r.state == 'self'):
            rec._check_weights()
            rec.activity_ids.filtered(lambda a: a.user_id == rec.employee_id.user_id).action_feedback(_('Self assessment submitted'))
            rec._move('manager', _('Submitted to the supervisor.'))
            rec._auto_rate()
            if rec.manager_id.user_id:
                rec.activity_schedule('mail.mail_activity_data_todo', date_deadline=rec.due_date,
                                      user_id=rec.manager_id.user_id.id, summary=_('Rate this evaluation'))

    def action_to_calibration(self):
        for rec in self.filtered(lambda r: r.state == 'manager'):
            rec._check_weights()
            rec._auto_rate()
            if not rec.is_complete:
                raise UserError(_('%s: the supervisor must rate every KPI and competency first.') % rec.name)
            rec.activity_ids.filtered(lambda a: a.user_id == rec.manager_id.user_id).action_feedback(_('Rated'))
            rec._move('calib', _('Submitted for calibration.'))

    def action_approve(self):
        if not self.env.user.has_group('beaeka_performance_evaluation.group_pe_admin'):
            raise UserError(_('Only performance evaluation administrators can approve.'))
        today = fields.Date.context_today(self)
        for rec in self.filtered(lambda r: r.state == 'calib'):
            rec._check_weights()
            if not rec.is_complete:
                raise UserError(_('%s: every KPI and competency must be rated.') % rec.name)
            if not rec.bsc_ok:
                raise UserError(_('Rate the company BSC for %s before approving; this form carries a company weight.') % rec.period_id.name)
            for line in rec.kpi_ids.filtered(lambda l: l.source and l.source != 'manual'):
                if line.source in DIR_SOURCES:
                    info = line._dir_result()
                    line.write({'frozen_actual': info[0] if info else 0.0, 'frozen_achievement': info[1] if info else 0.0,
                                'has_frozen': bool(info), 'actual_manual': '%.2f' % info[0] if info else False})
                    continue
                value = line._source_value()
                line.write({'frozen_actual': value or 0.0, 'has_frozen': value is not None,
                            'actual_manual': '%.2f' % value if value is not None else False})
            rec.write({'bsc_frozen': True, 'frozen_bsc': rec.period_id.bsc_score, 'approved_date': today})
            rec._move('done', _('Approved with a total score of %(s).1f%% (%(b)s).', s=rec.total_score, b=rec.band_id.name or ''))
            rec.activity_ids.action_feedback(_('Evaluation approved'))

    def action_send_back(self):
        order = [s for s, _l in STATES]
        for rec in self.filtered(lambda r: r.state not in ('draft', 'done')):
            rec._move(order[order.index(rec.state) - 1], _('Sent back to %s.') % dict(STATES)[order[order.index(rec.state) - 1]])

    def action_reopen(self):
        if not self.env.user.has_group('beaeka_performance_evaluation.group_pe_admin'):
            raise UserError(_('Only performance evaluation administrators can reopen.'))
        for rec in self.filtered(lambda r: r.state == 'done'):
            rec.kpi_ids.write({'has_frozen': False, 'frozen_actual': 0.0, 'frozen_achievement': 0.0})
            rec.write({'bsc_frozen': False, 'frozen_bsc': 0.0, 'approved_date': False})
            rec._move('calib', _('Reopened; the frozen company score and calculated actuals were released.'))

    def _auto_rate(self):
        """Give system-measured KPIs the rating their achievement suggests, unless the supervisor changed it."""
        if not param_bool(self.env, 'auto_rate', True):
            return
        ratings = {r.value: r for r in self.env['pe.rating'].sudo().search([])}
        for rec in self.filtered(lambda r: r.state in ('self', 'manager', 'calib')):
            for line in rec.kpi_ids.filtered(lambda l: l.source != 'manual' and (not l.rating_id or l.auto_rated)):
                rating = ratings.get(line.suggested_rating) if line.has_achievement else False
                if rating and line.rating_id != rating:
                    line.sudo().with_context(pe_auto_rate=True).write({'rating_id': rating.id, 'auto_rated': True})

    def action_auto_rate(self):
        self._auto_rate()

    def action_reload_kpis(self):
        for rec in self.filtered(lambda r: r.state == 'draft'):
            rec._load_kpis('auto')

    def action_print(self):
        return self.env.ref('beaeka_performance_evaluation.action_report_pe_evaluation').report_action(self)

    def unlink(self):
        if self.filtered(lambda r: r.state != 'draft') and not self.env.user.has_group('beaeka_performance_evaluation.group_pe_admin'):
            raise UserError(_('Only draft evaluations can be deleted.'))
        return super().unlink()

    # ------------------------------------------------------------------ report helpers
    def get_report_kpi_groups(self):
        self.ensure_one()
        lw = self._kpi_line_weights()
        groups = []
        for weight in self.weight_ids.sorted(lambda w: (w.perspective_id.sequence, w.id)):
            lines = self.kpi_ids.filtered(lambda l, p=weight.perspective_id: l.perspective_id == p)
            if lines:
                groups.append({'perspective': weight.perspective_id, 'weight': weight.weight,
                               'lines': [(line, lw[line]) for line in lines]})
        return groups


class PeEvaluationWeight(models.Model):
    _name = 'pe.evaluation.weight'
    _description = 'Evaluation Perspective Weight'
    _order = 'sequence, id'

    evaluation_id = fields.Many2one('pe.evaluation', required=True, ondelete='cascade', index=True)
    perspective_id = fields.Many2one('pe.perspective', required=True)
    sequence = fields.Integer(related='perspective_id.sequence', store=True)
    weight = fields.Float('Weight %')
    kpi_count = fields.Integer('KPIs', compute='_compute_split')
    per_kpi = fields.Float('% per KPI', compute='_compute_split')

    @api.depends('weight', 'evaluation_id.kpi_ids.perspective_id')
    def _compute_split(self):
        for rec in self:
            n = len(rec.evaluation_id.kpi_ids.filtered(lambda l: l.perspective_id == rec.perspective_id))
            rec.kpi_count = n
            rec.per_kpi = rec.weight / n if n else 0.0


class PeEvaluationKpi(models.Model):
    _name = 'pe.evaluation.kpi'
    _description = 'Evaluation KPI Line'
    _order = 'sequence, id'

    evaluation_id = fields.Many2one('pe.evaluation', required=True, ondelete='cascade', index=True)
    state = fields.Selection(related='evaluation_id.state')
    sequence = fields.Integer(default=10)
    perspective_id = fields.Many2one('pe.perspective', required=True)
    major_function = fields.Char()
    name = fields.Char('KPI')
    baseline = fields.Char()
    target = fields.Char(help='Use ≥ or ≤ with a number, e.g. ≥75%, ≤20 days, ≥3/5. A ≤ target is scored lower-is-better.')
    measure = fields.Char('How to measure')
    frequency = fields.Selection(FREQUENCY)
    evidence = fields.Char()
    initiatives = fields.Char('Priority initiatives')
    source = fields.Selection(SOURCE, string='Actual from', default='manual', required=True)
    dir_kpi_id = fields.Many2one('pe.directorate.kpi', string='Directorate KPI')
    kpi_weight = fields.Float('KPI weight', help='Optional. When set, the perspective weight is shared in proportion '
                                                 'to these weights instead of equally.')
    auto_rated = fields.Boolean('Rated by system', readonly=True, copy=False)
    actual_manual = fields.Char('Actual')
    frozen_actual = fields.Float(readonly=True, copy=False)
    frozen_achievement = fields.Float(readonly=True, copy=False)
    has_frozen = fields.Boolean(readonly=True, copy=False)
    actual_display = fields.Char('Calculated actual', compute='_compute_actual')
    achievement = fields.Float('Achieved %', compute='_compute_actual')
    has_achievement = fields.Boolean(compute='_compute_actual')
    suggested_rating = fields.Integer('Suggested', compute='_compute_actual')
    line_weight = fields.Float('Weight %', compute='_compute_line_weight')
    self_rating_id = fields.Many2one('pe.rating', string='Self rating')
    rating_id = fields.Many2one('pe.rating', string='Supervisor rating')
    weighted_score = fields.Float('Weighted', compute='_compute_line_weight')

    @api.depends('evaluation_id.weight_ids.weight', 'evaluation_id.kpi_ids.perspective_id', 'evaluation_id.kpi_ids.kpi_weight',
                 'perspective_id', 'kpi_weight', 'rating_id')
    def _compute_line_weight(self):
        maxv = self.env['pe.rating'].max_value()
        for rec in self:
            ev = rec.evaluation_id
            same = ev.kpi_ids.filtered(lambda l: l.perspective_id == rec.perspective_id)
            pw = sum(ev.weight_ids.filtered(lambda w: w.perspective_id == rec.perspective_id).mapped('weight'))
            total = sum(same.mapped('kpi_weight'))
            rec.line_weight = pw * rec.kpi_weight / total if total else pw / (len(same) or 1)
            rec.weighted_score = rec.line_weight * rec.rating_id.value / maxv if rec.rating_id else 0.0

    def write(self, vals):
        if 'rating_id' in vals and not self.env.context.get('pe_auto_rate'):
            vals = dict(vals, auto_rated=False)
        return super().write(vals)

    def _dir_result(self):
        """(result, achievement %) of a linked directorate KPI or scorecard for the evaluation period, or None."""
        self.ensure_one()
        period = self.evaluation_id.period_id
        if not period or not period.date_start or not period.date_end:
            return None
        if self.source == 'dir_kpi':
            kpi = self.dir_kpi_id.sudo()
            if not kpi:
                return None
            line = self.env['pe.scorecard.line'].sudo().search([('kpi_id', '=', kpi.id), ('date_from', '=', period.date_start),
                                                                 ('date_to', '=', period.date_end)], limit=1)
            if line:
                return (line.result, line.achievement) if line.has_data else None
            res = kpi.evaluate(period.date_start, period.date_end)
            return (res['result'], res['achievement']) if res['has_data'] else None
        if self.source == 'dir_score':
            directorate = self.env['pe.directorate'].for_employee(self.evaluation_id.employee_id.sudo())
            score = directorate.score_for_range(period.date_start, period.date_end) if directorate else None
            return None if score is None else (score, score)
        return None

    def _source_value(self):
        self.ensure_one()
        ev = self.evaluation_id
        period = ev.period_id
        if not period:
            return None
        min_n = int(param_float(self.env, 'min_responses', 3))
        if self.source == 'prc':
            emps = self.env['hr.employee'].sudo().search_count([('company_id', '=', ev.company_id.id), ('pe_excluded', '=', False)])
            if not emps:
                return None
            done = self.env['pe.evaluation'].sudo().search_count([('period_id', '=', period.id), ('state', '=', 'done'),
                                                                  ('company_id', '=', ev.company_id.id)])
            return done / emps * 100
        if self.source in ('lead_all', 'lead_self'):
            st = self.env['pe.leadership.response'].stats(period, ev.employee_id if self.source == 'lead_self' else None)
            return st['avg'] if st['n'] >= min_n else None
        if self.source in ('eng', 'enps'):
            st = self.env['pe.engagement.response'].stats(period)
            if st['n'] < min_n:
                return None
            return st['positive'] if self.source == 'eng' else st['enps']
        if self.source in DIR_SOURCES:
            info = self._dir_result()
            return info[0] if info else None
        return None

    def actual_value(self):
        self.ensure_one()
        if self.source and self.source != 'manual':
            if self.state == 'done' and self.has_frozen:
                return self.frozen_actual
            return self._source_value()
        return to_number(self.actual_manual)

    @api.depends('target', 'actual_manual', 'source', 'frozen_actual', 'frozen_achievement', 'has_frozen', 'state',
                 'dir_kpi_id')
    def _compute_actual(self):
        cuts = [(param_float(self.env, 'ach_5', 110.0), 5), (param_float(self.env, 'ach_4', 100.0), 4),
                (param_float(self.env, 'ach_3', 90.0), 3), (param_float(self.env, 'ach_2', 75.0), 2)]
        for rec in self:
            if rec.source in DIR_SOURCES:
                info = (rec.frozen_actual, rec.frozen_achievement) if rec.state == 'done' and rec.has_frozen else rec._dir_result()
                rec.actual_display = '%.2f' % info[0] if info else _('No data yet')
                ach = info[1] if info else None
                value = target = None
            else:
                value = rec.actual_value()
                if rec.source and rec.source != 'manual':
                    rec.actual_display = '%.2f' % value if value is not None else _('No data yet')
                else:
                    rec.actual_display = rec.actual_manual or False
                target, lower = parse_target(rec.target)
                ach = None
            if value is not None and target is not None:
                if lower:
                    ach = target / value * 100 if value > 0 else None
                elif target:
                    ach = value / target * 100
            rec.has_achievement = ach is not None
            rec.achievement = ach or 0.0
            suggested = 0
            if ach is not None:
                suggested = 1
                for cut, rating in cuts:
                    if ach >= cut:
                        suggested = rating
                        break
            rec.suggested_rating = suggested


class PeEvaluationCompetency(models.Model):
    _name = 'pe.evaluation.competency'
    _description = 'Evaluation Competency Line'
    _order = 'sequence, id'

    evaluation_id = fields.Many2one('pe.evaluation', required=True, ondelete='cascade', index=True)
    state = fields.Selection(related='evaluation_id.state')
    sequence = fields.Integer(default=10)
    name = fields.Char('Competency', required=True)
    weight = fields.Float('Weight %')
    self_rating_id = fields.Many2one('pe.rating', string='Self rating')
    rating_id = fields.Many2one('pe.rating', string='Supervisor rating')
    weighted_score = fields.Float('Weighted', compute='_compute_weighted')

    @api.depends('weight', 'rating_id')
    def _compute_weighted(self):
        maxv = self.env['pe.rating'].max_value()
        for rec in self:
            rec.weighted_score = rec.weight * rec.rating_id.value / maxv if rec.rating_id else 0.0
