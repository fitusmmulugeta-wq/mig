from datetime import date

from dateutil.relativedelta import relativedelta
from markupsafe import Markup, escape

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from .pe_config import param_bool, param_float
from .pe_directorate import STATUS, months_between

SCOPES = [('month', 'Month'), ('quarter', 'Quarter'), ('period', 'Evaluation period'), ('year', 'Fiscal year'),
          ('custom', 'Custom')]
STATES = [('open', 'In progress'), ('review', 'Data closing'), ('done', 'Closed')]


def scope_range(scope, day, period=None, fy_start_month=7):
    day = day or date.today()
    if scope == 'month':
        start = day.replace(day=1)
        return start, start + relativedelta(months=1, days=-1)
    if scope == 'quarter':
        start = day.replace(month=(day.month - 1) // 3 * 3 + 1, day=1)
        return start, start + relativedelta(months=3, days=-1)
    if scope == 'year':
        year = day.year if day.month >= fy_start_month else day.year - 1
        start = date(year, fy_start_month, 1)
        return start, start + relativedelta(months=12, days=-1)
    if scope == 'period' and period:
        return period.date_start, period.date_end
    return False, False


class PeScorecard(models.Model):
    _name = 'pe.scorecard'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Directorate Scorecard'
    _order = 'date_to desc, directorate_id'

    name = fields.Char(compute='_compute_name', store=True)
    directorate_id = fields.Many2one('pe.directorate', required=True, index=True, tracking=True)
    level = fields.Selection(related='directorate_id.level', store=True)
    parent_directorate_id = fields.Many2one(related='directorate_id.parent_id', store=True, string='Chief office')
    company_id = fields.Many2one(related='directorate_id.company_id', store=True)
    director_id = fields.Many2one(related='directorate_id.director_id', store=True, string='Director / Chief')
    chief_id = fields.Many2one(related='directorate_id.chief_id', string='Chief')
    scope = fields.Selection(SCOPES, required=True, default='month')
    period_id = fields.Many2one('pe.period', string='Evaluation period', index=True)
    date_from = fields.Date(required=True)
    date_to = fields.Date(required=True)
    state = fields.Selection(STATES, default='open', required=True, tracking=True)
    line_ids = fields.One2many('pe.scorecard.line', 'scorecard_id', string='KPIs')
    own_score = fields.Float('Own KPI score %', compute='_compute_score', store=True)
    child_score = fields.Float('Directorates score %', readonly=True)
    has_child_score = fields.Boolean(readonly=True)
    score = fields.Float('Score %', compute='_compute_score', store=True, aggregator='avg', tracking=True)
    has_data = fields.Boolean(compute='_compute_score', store=True)
    band_id = fields.Many2one('pe.score.band', string='Rating band', compute='_compute_score', store=True)
    status = fields.Selection(STATUS, compute='_compute_score', store=True)
    kpi_count = fields.Integer('Number of KPIs', compute='_compute_score', store=True)
    kpi_with_data = fields.Integer('KPIs with data', compute='_compute_score', store=True)
    green_count = fields.Integer('On track', compute='_compute_score', store=True)
    amber_count = fields.Integer('At risk', compute='_compute_score', store=True)
    red_count = fields.Integer('Off track', compute='_compute_score', store=True)
    missing_count = fields.Integer('Missing data', compute='_compute_score', store=True)
    weight_warning = fields.Char(compute='_compute_score', store=True)
    last_computed = fields.Datetime(readonly=True)
    closed_date = fields.Date(readonly=True)
    child_scorecard_ids = fields.Many2many('pe.scorecard', compute='_compute_children', string='Directorate scorecards')

    _range_uniq = models.Constraint(
        'unique(directorate_id, date_from, date_to)',
        'This directorate already has a scorecard for these dates.',
    )
    @api.depends('directorate_id', 'scope', 'date_from', 'date_to', 'period_id')
    def _compute_name(self):
        for rec in self:
            if not rec.date_from:
                rec.name = rec.directorate_id.name
                continue
            if rec.scope == 'month':
                label = rec.date_from.strftime('%b %Y')
            elif rec.scope == 'quarter':
                label = 'Q%s %s' % ((rec.date_from.month - 1) // 3 + 1, rec.date_from.year)
            elif rec.scope == 'period' and rec.period_id:
                label = rec.period_id.name
            elif rec.scope == 'year':
                label = 'FY %s/%s' % (rec.date_from.year, str(rec.date_to.year)[-2:])
            else:
                label = '%s → %s' % (rec.date_from, rec.date_to)
            rec.name = '%s — %s' % (rec.directorate_id.code or rec.directorate_id.name or '', label)

    def _compute_children(self):
        for rec in self:
            rec.child_scorecard_ids = self.search([('directorate_id', 'in', rec.directorate_id.child_ids.ids),
                                                   ('date_from', '=', rec.date_from), ('date_to', '=', rec.date_to)])

    @api.depends('line_ids.capped', 'line_ids.weight', 'line_ids.has_data', 'line_ids.status', 'child_score',
                 'has_child_score', 'directorate_id.own_kpi_share', 'directorate_id.level')
    def _compute_score(self):
        Band = self.env['pe.score.band']
        green = param_float(self.env, 'dir_green', 95.0)
        amber = param_float(self.env, 'dir_amber', 80.0)
        for rec in self:
            lines = rec.line_ids
            scored = lines.filtered('has_data')
            own = None
            if scored:
                den = sum(scored.mapped('weight'))
                own = (sum(l.capped * l.weight for l in scored) / den) if den else sum(scored.mapped('capped')) / len(scored)
            children = [(1.0, rec.child_score)] if rec.has_child_score else []
            total = rec.directorate_id._blend(own, children) if rec.directorate_id else own
            rec.own_score = own or 0.0
            rec.has_data = total is not None
            rec.score = total or 0.0
            rec.band_id = Band.band_for(total) if total is not None else False
            rec.status = 'nodata' if total is None else ('green' if total >= green else 'amber' if total >= amber else 'red')
            rec.kpi_count = len(lines)
            rec.kpi_with_data = len(scored)
            rec.green_count = len(lines.filtered(lambda l: l.status == 'green'))
            rec.amber_count = len(lines.filtered(lambda l: l.status == 'amber'))
            rec.red_count = len(lines.filtered(lambda l: l.status == 'red'))
            rec.missing_count = len(lines.filtered(lambda l: l.status == 'nodata'))
            wt = sum(lines.mapped('weight'))
            rec.weight_warning = (_('KPI weights in this scorecard total %.1f%%; the score is rescaled to 100%%.') % wt
                                  if lines and abs(wt - 100) > 0.01 else False)

    # ------------------------------------------------------------------ create
    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        for rec in recs:
            if rec.date_from > rec.date_to:
                raise UserError(_('The scorecard starts after it ends.'))
            rec._sync_lines()
            partners = rec.directorate_id._notify_partners()
            if partners:
                rec.message_subscribe(partner_ids=partners.ids)
        return recs

    def _sync_lines(self):
        for rec in self.filtered(lambda r: r.state != 'done'):
            have = rec.line_ids.mapped('kpi_id')
            kpis = rec.directorate_id.kpi_ids.filtered(lambda k: k.active and k not in have and k.in_scope(rec.date_from, rec.date_to))
            if kpis:
                rec.line_ids = [(0, 0, {'kpi_id': k.id, 'sequence': k.sequence, 'weight': k.weight}) for k in kpis]

    @api.model
    def ensure_scorecard(self, directorate, scope, day=None, period=None):
        date_from, date_to = scope_range(scope, day or fields.Date.context_today(self), period)
        if not date_from:
            return self.browse()
        card = self.search([('directorate_id', '=', directorate.id), ('date_from', '=', date_from), ('date_to', '=', date_to)], limit=1)
        if not card:
            card = self.create({'directorate_id': directorate.id, 'scope': scope, 'date_from': date_from, 'date_to': date_to,
                                'period_id': period.id if period else False})
        return card

    # ------------------------------------------------------------------ automatic evaluation
    def action_compute(self, notify=True):
        """Recalculate every line from Sales, Purchase, Analytic and the plan, then roll up chief offices."""
        cards = self.filtered(lambda r: r.state != 'done')
        # directorates first, chief offices after so they see fresh directorate scores
        for rec in cards.sorted(lambda r: 0 if r.level == 'directorate' else 1):
            rec._sync_lines()
            for line in rec.line_ids:
                line._refresh()
            children = self.search([('directorate_id', 'in', rec.directorate_id.child_ids.filtered('active').ids),
                                    ('date_from', '=', rec.date_from), ('date_to', '=', rec.date_to)])
            scored = [(c.directorate_id.rollup_weight or 0.0, c.score) for c in children if c.has_data]
            if scored:
                tw = sum(w for w, _s in scored)
                child = sum(w * s for w, s in scored) / tw if tw else sum(s for _w, s in scored) / len(scored)
                rec.write({'child_score': child, 'has_child_score': True})
            else:
                rec.write({'child_score': 0.0, 'has_child_score': False})
            rec.last_computed = fields.Datetime.now()
            if notify:
                rec._notify_red_kpis()
        return True

    def _post(self, subject, body, partners=None, extra_admins=False):
        self.ensure_one()
        partners = partners if partners is not None else self.directorate_id._notify_partners()
        if extra_admins and param_bool(self.env, 'dir_notify_admins', True):
            admins = self.env.ref('beaeka_performance_evaluation.group_pe_admin').all_user_ids.filtered(
                lambda u: not u.share and u.active and u.id not in (self.env.ref('base.user_root').id,))
            partners |= admins.partner_id
        self.message_post(body=body, subject=subject, partner_ids=partners.ids,
                          message_type='comment', subtype_xmlid='mail.mt_comment')

    def _line_table(self, lines):
        rows = ''.join(
            '<tr><td>%s</td><td>%s</td><td style="text-align:right">%s</td><td style="text-align:right">%s</td>'
            '<td style="text-align:right">%.1f%%</td></tr>' % (
                escape(l.code or ''), escape(l.name or ''), escape(l.result_display or '-'),
                escape(l.target_display or '-'), l.achievement)
            for l in lines)
        return Markup('<table class="table table-sm table-bordered"><thead><tr><th>Code</th><th>KPI</th><th>Result</th>'
                      '<th>Target</th><th>Achieved</th></tr></thead><tbody>%s</tbody></table>' % rows)

    def _notify_red_kpis(self):
        for rec in self:
            red = rec.line_ids.filtered(lambda l: l.status == 'red' and not l.notified_red)
            (rec.line_ids.filtered(lambda l: l.status != 'red' and l.notified_red)).write({'notified_red': False})
            if not red:
                continue
            body = Markup('<p>%s</p>') % _('%(n)s KPI(s) of %(d)s are off track in %(c)s:',
                                            n=len(red), d=rec.directorate_id.name, c=rec.name) + rec._line_table(red)
            partners = rec.directorate_id._notify_partners(with_chief=False) | red.mapped('owner_user_id.partner_id')
            rec._post(_('KPIs off track: %s') % rec.name, body, partners)
            red.write({'notified_red': True})

    def _remind_missing(self):
        today = fields.Date.context_today(self)
        days = int(param_float(self.env, 'dir_reminder_days', 5))
        summary = _('Enter scorecard actuals')
        for rec in self:
            if rec.state == 'done' or (rec.date_to - today).days > days:
                continue
            missing = rec.line_ids.filtered(lambda l: not l.is_auto and not l.has_data)
            for user in missing.mapped('owner_user_id'):
                mine = missing.filtered(lambda l: l.owner_user_id == user)
                if rec.activity_ids.filtered(lambda a: a.user_id == user and a.summary == summary):
                    continue
                deadline = max(rec.date_to + relativedelta(days=int(param_float(self.env, 'dir_grace_days', 10))), today)
                rec.activity_schedule('mail.mail_activity_data_todo', date_deadline=deadline, user_id=user.id,
                                      summary=summary, note=_('Missing: %s') % ', '.join(mine.mapped('code')))

    def action_review(self):
        for rec in self.filtered(lambda r: r.state == 'open'):
            rec.action_compute(notify=False)
            rec.state = 'review'
            grace = int(param_float(self.env, 'dir_grace_days', 10))
            missing = rec.line_ids.filtered(lambda l: not l.has_data)
            body = Markup('<p>%s</p>') % _('%(c)s has ended. Current score %(s).1f%%. Manual actuals can be entered until %(d)s, '
                                            'then the scorecard closes automatically.', c=rec.name, s=rec.score,
                                            d=rec.date_to + relativedelta(days=grace))
            if missing:
                body += Markup('<p>%s</p>') % (_('Still without data: %s') % ', '.join(missing.mapped('code')))
            rec._post(_('Scorecard data closing: %s') % rec.name, body)
            rec._remind_missing()

    def action_close(self):
        for rec in self.filtered(lambda r: r.state != 'done'):
            rec.action_compute(notify=False)
            rec.line_ids.write({'frozen': True})
            rec.write({'state': 'done', 'closed_date': fields.Date.context_today(rec)})
            rec.activity_ids.action_feedback(_('Scorecard closed'))
            rec._post_close_summary()
        return True

    def _post_close_summary(self):
        self.ensure_one()
        low = param_float(self.env, 'low_score', 60)
        pip = param_float(self.env, 'pip_score', 50)
        weak = self.line_ids.filtered(lambda l: l.status in ('red', 'amber')).sorted('achievement')[:8]
        body = Markup('<p>%s</p>') % _('%(c)s is closed. Final score <b>%(s).1f%%</b> (%(b)s). On track %(g)s · at risk %(a)s · '
                                        'off track %(r)s · no data %(m)s.', c=self.name, s=self.score,
                                        b=self.band_id.name or '-', g=self.green_count, a=self.amber_count,
                                        r=self.red_count, m=self.missing_count)
        if weak:
            body += Markup('<p>%s</p>') % _('Lowest KPIs:') + self._line_table(weak)
        self._post(_('Scorecard result: %s — %.1f%%') % (self.name, self.score), body, extra_admins=True)
        chief_user = self.directorate_id.parent_id.director_id.user_id
        if self.has_data and self.score < low and chief_user:
            self.activity_schedule('mail.mail_activity_data_todo', user_id=chief_user.id,
                                   date_deadline=fields.Date.context_today(self) + relativedelta(days=7),
                                   summary=_('Review low directorate score'),
                                   note=_('%(c)s scored %(s).1f%% (%(t)s).', c=self.name, s=self.score,
                                          t=_('improvement plan line') if self.score < pip else _('below expectation')))

    def action_reopen(self):
        if not self.env.user.has_group('beaeka_performance_evaluation.group_pe_admin'):
            raise UserError(_('Only performance evaluation administrators can reopen a closed scorecard.'))
        for rec in self.filtered(lambda r: r.state == 'done'):
            rec.line_ids.write({'frozen': False})
            rec.write({'state': 'review', 'closed_date': False})
            rec.message_post(body=_('Scorecard reopened.'))

    def action_print(self):
        return self.env.ref('beaeka_performance_evaluation.action_report_pe_scorecard').report_action(self)

    def unlink(self):
        if self.filtered(lambda r: r.state == 'done') and not self.env.user.has_group('beaeka_performance_evaluation.group_pe_admin'):
            raise UserError(_('Closed scorecards can only be deleted by an administrator.'))
        return super().unlink()

    # ------------------------------------------------------------------ cron
    @api.model
    def _cron_auto_evaluate(self):
        today = fields.Date.context_today(self)
        Dir = self.env['pe.directorate'].search([('active', '=', True)])
        period = self.env['pe.period'].get_current()
        for directorate in Dir:
            if not directorate.kpi_ids and not directorate.child_ids:
                continue
            if param_bool(self.env, 'dir_auto_month', True):
                self.ensure_scorecard(directorate, 'month', today)
            if param_bool(self.env, 'dir_auto_quarter', True):
                self.ensure_scorecard(directorate, 'quarter', today)
            if param_bool(self.env, 'dir_auto_year', False):
                self.ensure_scorecard(directorate, 'year', today)
            if period and period.date_start and period.date_end and param_bool(self.env, 'dir_auto_period', True):
                self.ensure_scorecard(directorate, 'period', today, period)
        grace = int(param_float(self.env, 'dir_grace_days', 10))
        active = self.search([('state', '!=', 'done')])
        active.action_compute()
        active.filtered(lambda r: r.state == 'open' and r.date_to < today).action_review()
        active.filtered(lambda r: r.state == 'review' and r.date_to + relativedelta(days=grace) < today).action_close()
        self.search([('state', '!=', 'done')])._remind_missing()
        self.env['pe.evaluation'].sudo().search([('state', 'in', ('manager', 'calib'))])._auto_rate()
        return True


class PeScorecardLine(models.Model):
    _name = 'pe.scorecard.line'
    _description = 'Directorate Scorecard KPI'
    _order = 'sequence, id'

    scorecard_id = fields.Many2one('pe.scorecard', required=True, ondelete='cascade', index=True)
    state = fields.Selection(related='scorecard_id.state')
    directorate_id = fields.Many2one(related='scorecard_id.directorate_id', store=True)
    date_from = fields.Date(related='scorecard_id.date_from', store=True)
    date_to = fields.Date(related='scorecard_id.date_to', store=True)
    scope = fields.Selection(related='scorecard_id.scope', store=True)
    company_id = fields.Many2one(related='scorecard_id.company_id', store=True)
    sequence = fields.Integer(default=10)
    kpi_id = fields.Many2one('pe.directorate.kpi', string='KPI', required=True, ondelete='cascade', index=True)
    code = fields.Char(related='kpi_id.code', store=True)
    name = fields.Char(related='kpi_id.name')
    perspective_id = fields.Many2one(related='kpi_id.perspective_id', store=True)
    formula = fields.Char(related='kpi_id.formula')
    unit = fields.Char(related='kpi_id.unit')
    frequency = fields.Selection(related='kpi_id.frequency')
    measure = fields.Selection(related='kpi_id.measure')
    calc_type = fields.Selection(related='kpi_id.calc_type')
    is_auto = fields.Boolean(related='kpi_id.is_auto')
    owner_user_id = fields.Many2one('res.users', compute='_compute_owner', store=True, string='Responsible')
    weight = fields.Float('Weight %')
    planned = fields.Float('Plan')
    has_plan = fields.Boolean()
    actual = fields.Float('Actual')
    has_actual = fields.Boolean()
    numerator = fields.Float()
    denominator = fields.Float()
    evidence = fields.Char('Evidence / comment')
    result = fields.Float('Result value', compute='_compute_result', store=True)
    result_display = fields.Char('Result', compute='_compute_result', store=True)
    target_value = fields.Float('Target value', compute='_compute_result', store=True)
    target_display = fields.Char('Target', compute='_compute_result', store=True)
    achievement = fields.Float('Achieved %', compute='_compute_result', store=True, aggregator='avg')
    capped = fields.Float('Counted %', compute='_compute_result', store=True, aggregator='avg')
    weighted_score = fields.Float('Weighted', compute='_compute_result', store=True)
    has_data = fields.Boolean(compute='_compute_result', store=True)
    status = fields.Selection(STATUS, compute='_compute_result', store=True)
    frozen = fields.Boolean(readonly=True)
    notified_red = fields.Boolean(readonly=True)

    @api.depends('kpi_id.owner_user_id', 'kpi_id.directorate_id.director_id.user_id')
    def _compute_owner(self):
        for rec in self:
            rec.owner_user_id = rec.kpi_id.responsible_user() if rec.kpi_id else False

    def _manual(self):
        return {'actual': self.actual if self.has_actual else None,
                'num': self.numerator if (self.numerator or self.denominator) else None,
                'den': self.denominator or None}

    @api.depends('planned', 'has_plan', 'actual', 'has_actual', 'numerator', 'denominator', 'weight',
                 'kpi_id.calc_type', 'kpi_id.direction', 'kpi_id.target_value', 'kpi_id.has_target',
                 'kpi_id.tolerance', 'kpi_id.threshold_value')
    def _compute_result(self):
        for rec in self:
            if not rec.kpi_id:
                rec.update({'result': 0.0, 'result_display': False, 'target_value': 0.0, 'target_display': False,
                            'achievement': 0.0, 'capped': 0.0, 'weighted_score': 0.0, 'has_data': False, 'status': 'nodata'})
                continue
            kpi = rec.kpi_id
            res = kpi.score_values(rec.planned if rec.has_plan else None, *rec._manual().values())
            pct = kpi.calc_type in ('plan', 'plan_inv', 'ratio', 'variance') or (kpi.unit or '').strip() == '%'
            fmt = (lambda v: '%.1f%%' % v) if pct else (lambda v: '{:,.2f}'.format(v))
            rec.result = res['result'] or 0.0
            rec.result_display = fmt(res['result']) if res['result'] is not None else False
            rec.target_value = res['target'] or 0.0
            if res['target'] is None:
                rec.target_display = kpi.target or False
            elif kpi.direction == 'band':
                rec.target_display = '±%g%%' % kpi.tolerance
            else:
                rec.target_display = ('≤ ' if kpi.direction == 'lower' else '≥ ') + fmt(res['target'])
            rec.achievement = res['achievement']
            rec.capped = res['capped']
            rec.weighted_score = res['capped'] * rec.weight / 100.0
            rec.has_data = res['has_data']
            rec.status = res['status']

    def _refresh(self):
        """Pull the plan and, for automatic KPIs, the actual from the ERP."""
        for rec in self.filtered(lambda l: not l.frozen):
            card = rec.scorecard_id
            directorate = card.directorate_id
            vals = {}
            planned = directorate.planned_value(rec.kpi_id, card.date_from, card.date_to)
            vals.update(planned=planned or 0.0, has_plan=planned is not None)
            if rec.is_auto:
                data = directorate.measure_value(rec.kpi_id.measure, card.date_from, card.date_to) or {}
                vals.update(actual=data.get('actual') or 0.0, has_actual=data.get('actual') is not None,
                            numerator=data.get('num') or 0.0, denominator=data.get('den') or 0.0)
            if not rec.weight and rec.kpi_id.weight:
                vals['weight'] = rec.kpi_id.weight
            rec.write(vals)

    @api.onchange('actual')
    def _onchange_actual(self):
        self.has_actual = True

    def write(self, vals):
        if 'actual' in vals and 'has_actual' not in vals:
            vals['has_actual'] = vals['actual'] is not False and vals['actual'] is not None
        if any(f in vals for f in ('actual', 'numerator', 'denominator', 'planned')) and not self.env.su:
            if self.filtered(lambda l: l.frozen):
                raise UserError(_('This scorecard is closed.'))
        return super().write(vals)
