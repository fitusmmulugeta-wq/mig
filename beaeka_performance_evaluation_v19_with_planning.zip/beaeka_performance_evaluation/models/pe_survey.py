from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from .pe_config import param_bool

LEAD_QUESTIONS = ['q1', 'q2', 'q3', 'q4', 'q5']


class PeLeadershipResponse(models.Model):
    _name = 'pe.leadership.response'
    _description = 'Leadership Effectiveness Response'
    _order = 'id desc'
    _rec_name = 'leader_id'

    period_id = fields.Many2one('pe.period', required=True, ondelete='restrict', index=True)
    leader_id = fields.Many2one('hr.employee', string='Leader', required=True, ondelete='cascade', index=True)
    department_id = fields.Many2one(related='leader_id.department_id', store=True)
    company_id = fields.Many2one(related='leader_id.company_id', store=True)
    q1 = fields.Integer('Clarity', aggregator='avg', required=True)
    q2 = fields.Integer('Support', aggregator='avg', required=True)
    q3 = fields.Integer('Safety', aggregator='avg', required=True)
    q4 = fields.Integer('Growth', aggregator='avg', required=True)
    q5 = fields.Integer('Loyalty', aggregator='avg', required=True)
    average = fields.Float(compute='_compute_average', store=True, aggregator='avg')
    response_key = fields.Char(index=True, copy=False, groups='base.group_system')

    _key_uniq = models.Constraint(
        'unique(response_key)',
        'A response for this leader and period has already been recorded from this account.',
    )
    @api.depends(*LEAD_QUESTIONS)
    def _compute_average(self):
        for rec in self:
            rec.average = sum(rec[q] for q in LEAD_QUESTIONS) / 5.0

    @api.constrains(*LEAD_QUESTIONS)
    def _check_range(self):
        for rec in self:
            if any(not 1 <= rec[q] <= 5 for q in LEAD_QUESTIONS):
                raise ValidationError(_('Leadership ratings must be between 1 and 5.'))

    @api.model
    def stats(self, period, leader=None):
        domain = [('period_id', '=', period.id)]
        if leader:
            domain.append(('leader_id', '=', leader.id))
        recs = self.sudo().search(domain)
        n = len(recs)
        items = [sum(recs.mapped(q)) / n if n else 0.0 for q in LEAD_QUESTIONS]
        return {'n': n, 'items': items, 'avg': sum(items) / len(items) if n else 0.0}


class PeEngagementResponse(models.Model):
    _name = 'pe.engagement.response'
    _description = 'Employee Engagement (eNPS) Response'
    _order = 'id desc'

    period_id = fields.Many2one('pe.period', required=True, ondelete='restrict', index=True)
    department_id = fields.Many2one('hr.department', string="Respondent's unit")
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    score = fields.Integer(required=True, aggregator='avg')
    category = fields.Selection([('promoter', 'Promoter (9-10)'), ('passive', 'Passive (7-8)'),
                                 ('detractor', 'Detractor (0-6)')], compute='_compute_points', store=True)
    enps_point = fields.Float('eNPS', compute='_compute_points', store=True, aggregator='avg',
                              help='+100 promoter, 0 passive, -100 detractor; the average is the eNPS.')
    positive_point = fields.Float('Positive %', compute='_compute_points', store=True, aggregator='avg')
    response_key = fields.Char(index=True, copy=False, groups='base.group_system')

    _key_uniq = models.Constraint(
        'unique(response_key)',
        'An engagement response for this period has already been recorded from this account.',
    )
    @api.depends('score')
    def _compute_points(self):
        passives = param_bool(self.env, 'passives_positive', False)
        for rec in self:
            if rec.score >= 9:
                rec.category, rec.enps_point, rec.positive_point = 'promoter', 100.0, 100.0
            elif rec.score >= 7:
                rec.category, rec.enps_point, rec.positive_point = 'passive', 0.0, 100.0 if passives else 0.0
            else:
                rec.category, rec.enps_point, rec.positive_point = 'detractor', -100.0, 0.0

    @api.constrains('score')
    def _check_score(self):
        for rec in self:
            if not 0 <= rec.score <= 10:
                raise ValidationError(_('The engagement score must be between 0 and 10.'))

    @api.model
    def stats(self, period, department=None):
        domain = [('period_id', '=', period.id)]
        if department:
            domain.append(('department_id', '=', department.id))
        recs = self.sudo().search(domain)
        n = len(recs)
        pro = len(recs.filtered(lambda r: r.score >= 9))
        det = len(recs.filtered(lambda r: r.score <= 6))
        pas = n - pro - det
        passives = param_bool(self.env, 'passives_positive', False)
        return {
            'n': n, 'pro': pro, 'pas': pas, 'det': det,
            'enps': (pro - det) / n * 100 if n else 0.0,
            'positive': (pro + (pas if passives else 0)) / n * 100 if n else 0.0,
        }
