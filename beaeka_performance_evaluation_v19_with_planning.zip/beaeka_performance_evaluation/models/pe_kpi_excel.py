"""Read the BEAEKA "Directorate KPIs by Department" workbook (Integrated PM with BSC).

Pure python (no Odoo imports) so the same rules are used by the import wizard and by
the script that generated data/pe_directorate_kpi_data.xml.
"""
import io
import re

HEADERS = {
    'directorate': 'directorate', 'kpi code': 'code', 'strategic objective': 'strategic_objective',
    'kpi name': 'name', 'kpi definition': 'definition', 'formula': 'formula', 'unit': 'unit',
    'baseline': 'baseline', 'kpi weight': 'weight', 'target': 'target', 'annual target': 'annual_target',
    'threshold': 'threshold', 'stretch target': 'stretch_target', 'data source': 'data_source',
    'frequency': 'frequency', 'kpi owner': 'kpi_owner', 'data owner': 'data_owner', 'reviewer': 'reviewer',
    'approver': 'approver', 'evidence required': 'evidence',
}
FREQ_MAP = {'monthly': 'monthly', 'monthl': 'monthly', 'quarterly': 'quarterly', 'semi-annual': 'semi',
            'semi annual': 'semi', 'annual': 'annual', 'seasonal': 'seasonal'}


def clean(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return re.sub(r'\s+', ' ', str(value)).strip()


def clean_directorate(name):
    return clean(name).lstrip('. ').strip()


def _num(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    m = re.search(r'-?\d+(?:\.\d+)?', str(value or '').replace(',', ''))
    return float(m.group(0)) if m else None


def classify(row):
    """Return Odoo field values derived from one spreadsheet row."""
    name = clean(row.get('name'))
    formula = clean(row.get('formula'))
    unit = clean(row.get('unit'))
    raw_target = row.get('target')
    raw_weight = row.get('weight')
    notes = []

    # Some sheets (e.g. Manufacturing Office) carry the weight one column to the right.
    if raw_weight in (None, '') and isinstance(raw_target, (int, float)) and 0 < raw_target < 1:
        raw_weight, raw_target = raw_target, None
        notes.append('weight read from the Target column')
    weight = _num(raw_weight) or 0.0
    if weight and weight <= 1.0:
        weight *= 100.0

    f, n = formula.lower(), name.lower()
    text = '%s %s' % (n, f)

    # ---- target and direction
    target_text = clean(raw_target)
    direction, tolerance, target_value, has_target = 'higher', 0.0, 0.0, False
    if isinstance(raw_target, (int, float)) and not isinstance(raw_target, bool):
        target_value = float(raw_target) * 100.0 if float(raw_target) <= 1.5 else float(raw_target)
        target_text = '%g%%' % target_value if float(raw_target) <= 1.5 else target_text
        has_target = True
    elif target_text:
        low = target_text.lower()
        if '±' in target_text or 'variance' in low:
            direction, tolerance = 'band', _num(target_text) or 5.0
            target_value, has_target = 0.0, True
        else:
            number = _num(target_text)
            if number is not None:
                target_value, has_target = number, True
            if re.search(r'≤|<=|\bmax\b', low) or low in ('reducing', 'decreasing'):
                direction = 'lower'

    # ---- what feeds the actual, and how the result is calculated
    measure, calc = 'manual', None
    rules = [
        (r'budget variance', 'analytic_cost', 'variance'),
        (r'actual sales volume|sales volume ÷ planned', 'sale_qty', 'plan'),
        (r'actual sales revenue|actual revenue|actual sales ÷|actual income|actual premium', 'sale_invoiced', 'plan'),
        (r'gross margin', 'sale_margin', 'plan'),
        (r'gross profit|operating profit|actual profit', 'analytic_net', 'plan'),
        (r'new customers acquired', 'new_customers', 'plan'),
        (r'collected receivables|collections ÷ receivables', 'collection', 'ratio'),
        (r'actual procurement', 'purchase_amount', 'plan'),
        (r'budget cost ÷ actual cost', 'analytic_cost', 'plan_inv'),
        (r'completed appraisals', 'eval_completion', 'ratio'),
        (r'sales revenue ÷ number of employees', 'revenue_per_employee', 'value'),
        (r'procurement value ÷ employees', 'purchase_per_employee', 'value'),
    ]
    for pattern, m_key, c_key in rules:
        if re.search(pattern, f):
            measure, calc = m_key, c_key
            break
    if not calc:
        if re.match(r'(actual|standard|budget)\b.*÷\s*(planned|plan|approved|budget)', f) or \
                re.search(r'÷\s*planned (savings|income|cash|output|production|volume|revenue|premium)', f):
            calc = 'plan'
        elif re.match(r'(standard|budget)\b.*÷\s*actual', f):
            calc = 'plan_inv'
        elif '÷' in f and '×100' in f.replace(' ', ''):
            calc = 'ratio'
        else:
            calc = 'value'
    if calc == 'value' and not has_target:
        notes.append('target taken from the plan')

    # ---- BSC perspective
    if re.search(r'capacity building|training|competenc|certification|productivity|innovation|digital|automation|'
                 r'culture|succession|capability|recruitment|employee turnover|employee satisfaction|improvement', text):
        persp = 'lnd'
    elif re.search(r'revenue|profit|cost|cash|budget|saving|premium|income|margin|sales volume|collection|loss ratio|'
                   r'market sales', text):
        persp = 'fin'
    elif re.search(r'customer|market share|brand|reputation|stakeholder|media|dealer|csr|claims settlement|'
                   r'retention|acquisition', text):
        persp = 'cus'
    else:
        persp = 'int'

    freq = FREQ_MAP.get(clean(row.get('frequency')).lower(), False)
    return {
        'code': clean(row.get('code')),
        'name': name,
        'definition': clean(row.get('definition')),
        'strategic_objective': clean(row.get('strategic_objective')),
        'formula': formula,
        'unit': unit,
        'baseline': clean(row.get('baseline')),
        'weight': round(weight, 4),
        'target': target_text,
        'target_value': target_value,
        'has_target': has_target,
        'direction': direction,
        'tolerance': tolerance,
        'annual_target': clean(row.get('annual_target')),
        'threshold': clean(row.get('threshold')),
        'stretch_target': clean(row.get('stretch_target')),
        'data_source': clean(row.get('data_source')),
        'frequency': freq,
        'kpi_owner': clean(row.get('kpi_owner')),
        'data_owner': clean(row.get('data_owner')),
        'reviewer': clean(row.get('reviewer')),
        'approver': clean(row.get('approver')),
        'evidence': clean(row.get('evidence')),
        'measure': measure,
        'calc_type': calc,
        'perspective': persp,
        'import_note': '; '.join(notes),
    }


def _header_map(row):
    found = {}
    for idx, cell in enumerate(row):
        key = HEADERS.get(clean(cell).lower())
        if key and key not in found:
            found[key] = idx
    return found if {'code', 'name'} <= set(found) else None


def read_rows(file_bytes):
    """Yield (directorate, values) for every KPI row of the workbook.

    Uses the consolidated "Integrated PM with BSC" sheet when present, otherwise every sheet
    that has a KPI Code header. Rows without a directorate inherit the one above them.
    """
    from openpyxl import load_workbook  # imported lazily: only needed when importing
    wb = load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
    names = wb.sheetnames
    main = [s for s in names if s.strip().lower().startswith('integrated pm')]
    sheets = main or [s for s in names if s.strip().lower() != 'directorate summary']
    seen = set()
    for sheet in sheets:
        ws = wb[sheet]
        header, last_dir = None, ''
        for row in ws.iter_rows(values_only=True):
            if header is None:
                header = _header_map(row)
                continue
            get = lambda key: row[header[key]] if key in header and header[key] < len(row) else None
            code = clean(get('code'))
            name = clean(get('name'))
            if not code or not name:
                continue
            directorate = clean_directorate(get('directorate')) or last_dir
            last_dir = directorate
            if not directorate or (directorate.lower(), code.upper()) in seen:
                continue
            seen.add((directorate.lower(), code.upper()))
            raw = {key: get(key) for key in HEADERS.values()}
            yield directorate, classify(raw)
    wb.close()
