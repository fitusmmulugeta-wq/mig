from datetime import datetime, time

from odoo import api, fields, models, _
from odoo.fields import Domain

from .pe_config import FREQUENCY, param_float

MEASURES = [
    ('manual', 'Manual entry'),
    ('sale_invoiced', 'Sales: invoiced revenue (posted, net of credit notes)'),
    ('sale_ordered', 'Sales: confirmed sales orders (untaxed)'),
    ('sale_qty', 'Sales: quantity ordered'),
    ('sale_margin', 'Sales: margin on confirmed orders'),
    ('new_customers', 'Sales: new customers (first confirmed order)'),
    ('collection', 'Accounting: collection rate of invoices due'),
    ('purchase_amount', 'Purchase: confirmed purchase orders (untaxed)'),
    ('purchase_on_time', 'Purchase: orders received on time'),
    ('analytic_revenue', 'Analytic: revenue'),
    ('analytic_cost', 'Analytic: cost'),
    ('analytic_net', 'Analytic: profit (revenue - cost)'),
    ('revenue_per_employee', 'Sales revenue per employee'),
    ('purchase_per_employee', 'Purchase value per employee'),
    ('eval_completion', 'HR: performance evaluation completion'),
]
CALC_TYPES = [
    ('plan', 'Actual ÷ Plan × 100'),
    ('plan_inv', 'Plan ÷ Actual × 100'),
    ('ratio', 'Numerator ÷ Denominator × 100'),
    ('value', 'Value compared to target'),
    ('variance', '(Actual − Plan) ÷ Plan × 100'),
]
DIRECTIONS = [('higher', 'Higher is better'), ('lower', 'Lower is better'), ('band', 'Within ± tolerance')]
STATUS = [('green', 'On track'), ('amber', 'At risk'), ('red', 'Off track'), ('nodata', 'No data')]
FREQ_MONTHS = {'monthly': 1, 'quarterly': 3, 'semi': 6, 'seasonal': 6, 'annual': 12}
# measures whose result is a ratio already (numerator / denominator)
RATIO_MEASURES = ('collection', 'purchase_on_time', 'eval_completion')
VALUE_MEASURES = ('revenue_per_employee', 'purchase_per_employee')


def months_between(date_from, date_to):
    if not date_from or not date_to:
        return 0
    return (date_to.year - date_from.year) * 12 + date_to.month - date_from.month + 1


def dt_range(date_from, date_to):
    return datetime.combine(date_from, time.min), datetime.combine(date_to, time.max)


class PeDirectorate(models.Model):
    _name = 'pe.directorate'
    _inherit = ['mail.thread']
    _description = 'Directorate / Chief Office'
    _order = 'sequence, name'

    name = fields.Char(required=True, tracking=True)
    code = fields.Char('Short code', help='Prefix of its KPI codes, e.g. FIN, MKT.')
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    currency_id = fields.Many2one(related='company_id.currency_id')
    level = fields.Selection([('chief', 'Chief office'), ('directorate', 'Directorate')], default='directorate',
                             required=True, tracking=True)
    parent_id = fields.Many2one('pe.directorate', string='Reports to (chief office)', domain="[('level', '=', 'chief')]",
                                index=True, tracking=True)
    child_ids = fields.One2many('pe.directorate', 'parent_id', string='Directorates')
    director_id = fields.Many2one('hr.employee', string='Director / Chief', tracking=True,
                                  help='Accountable head. Receives the scorecard notifications and is evaluated on this scorecard.')
    director_user_id = fields.Many2one(related='director_id.user_id', string='Director user')
    chief_id = fields.Many2one(related='parent_id.director_id', string='Chief')
    member_user_ids = fields.Many2many('res.users', 'pe_directorate_member_rel', 'directorate_id', 'user_id',
                                       string='Data owners', help='Users allowed to enter manual actuals for this scorecard. '
                                                                  'They need the Performance Evaluation / Supervisor group.')
    department_ids = fields.Many2many('hr.department', string='Departments',
                                      help='Departments (and their sub-departments) that belong to this directorate. Used for headcount and evaluations.')
    analytic_account_ids = fields.Many2many('account.analytic.account', string='Analytic accounts',
                                            help='Sales, purchase, invoice and analytic lines carrying these accounts are counted for this directorate.')
    team_ids = fields.Many2many('crm.team', string='Sales teams', help='Optional: sales orders and invoices of these teams also count.')
    company_wide = fields.Boolean('Use all company data', help='Count every sale, purchase and analytic line of the company. '
                                                                'Use for group level offices without their own analytic account.')
    kpi_ids = fields.One2many('pe.directorate.kpi', 'directorate_id', string='KPIs', copy=True)
    kpi_count = fields.Integer(compute='_compute_kpi_stats')
    weight_total = fields.Float('Total KPI weight %', compute='_compute_kpi_stats')
    weight_ok = fields.Boolean(compute='_compute_kpi_stats')
    rollup_weight = fields.Float('Weight in chief score', default=1.0,
                                 help="Relative weight of this directorate's score in its chief office score.")
    own_kpi_share = fields.Float('Own KPIs share %', default=50.0,
                                 help='Chief offices only: share of the score that comes from their own KPIs; '
                                      'the rest is the weighted average of their directorates.')
    plan_ids = fields.One2many('pe.plan', 'directorate_id')
    scorecard_ids = fields.One2many('pe.scorecard', 'directorate_id')
    scorecard_count = fields.Integer(compute='_compute_counts')
    plan_count = fields.Integer(compute='_compute_counts')
    last_score = fields.Float('Last closed score %', compute='_compute_counts')
    link_warning = fields.Char(compute='_compute_link_warning')

    _name_company_uniq = models.Constraint(
        'unique(name, company_id)',
        'A directorate with this name already exists.',
    )
    @api.depends('kpi_ids.weight', 'kpi_ids.active')
    def _compute_kpi_stats(self):
        for rec in self:
            kpis = rec.kpi_ids.filtered('active')
            rec.kpi_count = len(kpis)
            rec.weight_total = sum(kpis.mapped('weight'))
            rec.weight_ok = abs(rec.weight_total - 100) < 0.01

    def _compute_counts(self):
        for rec in self:
            rec.scorecard_count = len(rec.scorecard_ids)
            rec.plan_count = len(rec.plan_ids)
            done = rec.scorecard_ids.filtered(lambda s: s.state == 'done').sorted('date_to', reverse=True)
            rec.last_score = done[:1].score if done else 0.0

    @api.depends('analytic_account_ids', 'team_ids', 'company_wide', 'kpi_ids.measure')
    def _compute_link_warning(self):
        for rec in self:
            needs = rec.kpi_ids.filtered(lambda k: k.active and k.measure not in ('manual', 'eval_completion'))
            if needs and not (rec.analytic_account_ids or rec.team_ids or rec.company_wide):
                rec.link_warning = _('%s KPI(s) read Sales/Purchase/Analytic data, but no analytic account or sales team is set: '
                                     'they will show "No data".') % len(needs)
            else:
                rec.link_warning = False

    @api.depends('name', 'code')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '[%s] %s' % (rec.code, rec.name) if rec.code else rec.name

    # ------------------------------------------------------------------ people
    def _notify_partners(self, with_chief=True):
        partners = self.env['res.partner']
        for rec in self:
            partners |= rec.director_id.user_id.partner_id | rec.member_user_ids.partner_id
            if with_chief:
                partners |= rec.parent_id.director_id.user_id.partner_id
        return partners

    def _employees(self):
        self.ensure_one()
        if not self.department_ids:
            return self.env['hr.employee']
        return self.env['hr.employee'].sudo().search([('department_id', 'child_of', self.department_ids.ids),
                                                      ('company_id', '=', self.company_id.id)])

    @api.model
    def for_employee(self, employee):
        """Directorate an employee heads, else the one owning their department."""
        if not employee:
            return self.browse()
        led = self.sudo().search([('director_id', '=', employee.id)], limit=1)
        if led or not employee.department_id:
            return led
        dept = employee.department_id
        for rec in self.sudo().search([('department_ids', '!=', False)]):
            if dept in self.env['hr.department'].sudo().search([('id', 'child_of', rec.department_ids.ids)]):
                return rec
        return self.browse()

    # ------------------------------------------------------------------ data sources
    def _linked(self):
        self.ensure_one()
        return bool(self.analytic_account_ids or self.team_ids or self.company_wide)

    def _share(self, distribution):
        """Share (0-1) of an analytic distribution that belongs to this directorate."""
        if not distribution or not self.analytic_account_ids:
            return 0.0
        ids = set(self.analytic_account_ids.ids)
        share = 0.0
        for key, pct in distribution.items():
            if ids & {int(x) for x in str(key).split(',') if x.strip().isdigit()}:
                share += (pct or 0.0) / 100.0
        return min(share, 1.0)

    def _line_domain(self, team_field):
        """Domain on analytic.mixin lines limiting them to this directorate (None = all company)."""
        self.ensure_one()
        if self.company_wide:
            return []
        parts = []
        if self.analytic_account_ids:
            parts.append([('analytic_distribution', 'in', self.analytic_account_ids.ids)])
        if self.team_ids and team_field:
            parts.append([(team_field, 'in', self.team_ids.ids)])
        return list(Domain.OR(parts)) if parts else None

    def _line_share(self, line, team):
        if self.company_wide:
            return 1.0
        share = self._share(line.analytic_distribution)
        if not share and team and team in self.team_ids:
            share = 1.0
        return share

    def _convert(self, amount, currency, date):
        company = self.company_id
        if not currency or currency == company.currency_id:
            return amount
        return currency._convert(amount, company.currency_id, company, date or fields.Date.today())

    def _invoice_lines(self, date_from, date_to, extra=None):
        dom = self._line_domain('move_id.team_id' if 'team_id' in self.env['account.move']._fields else None)
        if dom is None:
            return None
        base = [('company_id', '=', self.company_id.id), ('parent_state', '=', 'posted'), ('display_type', '=', 'product'),
                ('move_id.move_type', 'in', ('out_invoice', 'out_refund'))]
        if extra is None:
            extra = [('date', '>=', date_from), ('date', '<=', date_to)]
        return self.env['account.move.line'].sudo().search(Domain.AND([base, extra, dom or []]))

    def _sale_lines(self, date_from, date_to):
        if 'sale.order.line' not in self.env:
            return None
        dom = self._line_domain('order_id.team_id')
        if dom is None:
            return None
        start, end = dt_range(date_from, date_to)
        base = [('order_id.company_id', '=', self.company_id.id), ('order_id.state', '=', 'sale'),
                ('order_id.date_order', '>=', start), ('order_id.date_order', '<=', end), ('display_type', '=', False)]
        return self.env['sale.order.line'].sudo().search(Domain.AND([base, dom]))

    def _purchase_lines(self, date_from, date_to):
        if 'purchase.order.line' not in self.env:
            return None
        dom = self._line_domain(None)
        if dom is None:
            return None
        start, end = dt_range(date_from, date_to)
        base = [('order_id.company_id', '=', self.company_id.id), ('order_id.state', 'in', ('purchase', 'done')),
                ('order_id.date_approve', '>=', start), ('order_id.date_approve', '<=', end), ('display_type', '=', False)]
        return self.env['purchase.order.line'].sudo().search(Domain.AND([base, dom]))

    def _analytic_lines(self, date_from, date_to):
        AAL = self.env['account.analytic.line'].sudo()
        base = [('company_id', 'in', (self.company_id.id, False)), ('date', '>=', date_from), ('date', '<=', date_to)]
        if self.company_wide:
            return AAL.search(base)
        if not self.analytic_account_ids:
            return None
        by_col = {}
        for acc in self.analytic_account_ids:
            plan = acc.root_plan_id if 'root_plan_id' in acc._fields else acc.plan_id
            col = plan._column_name() if hasattr(plan, '_column_name') else 'account_id'
            if col not in AAL._fields:
                col = 'account_id'
            by_col.setdefault(col, []).append(acc.id)
        dom = Domain.OR([[(col, 'in', ids)] for col, ids in by_col.items()])
        return AAL.search(Domain.AND([base, dom]))

    def _sale_revenue(self, date_from, date_to):
        lines = self._invoice_lines(date_from, date_to)
        if lines is None:
            return None
        team_ok = 'team_id' in self.env['account.move']._fields
        return sum(-line.balance * self._line_share(line, line.move_id.team_id if team_ok else False) for line in lines)

    def _purchase_value(self, date_from, date_to):
        lines = self._purchase_lines(date_from, date_to)
        if lines is None:
            return None
        return sum(self._convert(l.price_subtotal, l.order_id.currency_id, l.order_id.date_approve) * self._line_share(l, False)
                   for l in lines)

    def measure_value(self, measure, date_from, date_to):
        """Return {'actual': x} or {'num': a, 'den': b}; None when the source is not available."""
        self.ensure_one()
        if measure == 'manual':
            return None
        if measure == 'eval_completion':
            emps = self._employees().filtered(lambda e: not e.pe_excluded)
            periods = self.env['pe.period'].sudo().search([('date_start', '<=', date_to), ('date_end', '>=', date_from)])
            if not emps or not periods:
                return None
            done = self.env['pe.evaluation'].sudo().search_count([('period_id', 'in', periods.ids), ('state', '=', 'done'),
                                                                  ('employee_id', 'in', emps.ids)])
            return {'num': float(done), 'den': float(len(emps) * len(periods))}
        if not self._linked():
            return None
        if measure == 'sale_invoiced':
            value = self._sale_revenue(date_from, date_to)
            return None if value is None else {'actual': value}
        if measure in ('sale_ordered', 'sale_qty', 'sale_margin', 'new_customers'):
            lines = self._sale_lines(date_from, date_to)
            if lines is None:
                return None
            if measure == 'sale_margin' and 'margin' not in lines._fields:
                return None
            total = 0.0
            for line in lines:
                share = self._line_share(line, line.order_id.team_id)
                if measure == 'sale_ordered':
                    total += self._convert(line.price_subtotal, line.order_id.currency_id, line.order_id.date_order) * share
                elif measure == 'sale_qty':
                    total += line.product_uom_qty * share
                elif measure == 'sale_margin':
                    total += self._convert(line.margin, line.order_id.currency_id, line.order_id.date_order) * share
            if measure == 'new_customers':
                partners = lines.filtered(lambda l: self._line_share(l, l.order_id.team_id)).mapped('order_id.partner_id.commercial_partner_id')
                start, _end = dt_range(date_from, date_to)
                old = self.env['sale.order'].sudo().search([('partner_id', 'child_of', partners.ids), ('state', '=', 'sale'),
                                                            ('date_order', '<', start), ('company_id', '=', self.company_id.id)]
                                                           ).mapped('partner_id.commercial_partner_id') if partners else partners
                total = float(len(partners - old))
            return {'actual': total}
        if measure == 'collection':
            lines = self._invoice_lines(date_from, date_to, [('move_id.invoice_date_due', '>=', date_from),
                                                             ('move_id.invoice_date_due', '<=', date_to),
                                                             ('move_id.move_type', '=', 'out_invoice')])
            if lines is None:
                return None
            moves = lines.mapped('move_id')
            den = sum(moves.mapped('amount_total_signed'))
            num = sum(m.amount_total_signed - m.amount_residual_signed for m in moves)
            return {'num': num, 'den': den} if den else None
        if measure == 'purchase_amount':
            value = self._purchase_value(date_from, date_to)
            return None if value is None else {'actual': value}
        if measure == 'purchase_on_time':
            if 'effective_date' not in self.env['purchase.order']._fields:
                return None
            lines = self._purchase_lines(date_from, date_to)
            if lines is None:
                return None
            orders = lines.mapped('order_id').filtered(lambda o: o.date_planned and o.date_planned.date() <= fields.Date.today())
            if not orders:
                return None
            on_time = orders.filtered(lambda o: o.effective_date and o.effective_date <= o.date_planned)
            return {'num': float(len(on_time)), 'den': float(len(orders))}
        if measure in ('analytic_revenue', 'analytic_cost', 'analytic_net'):
            lines = self._analytic_lines(date_from, date_to)
            if lines is None:
                return None
            revenue = sum(a for a in lines.mapped('amount') if a > 0)
            cost = -sum(a for a in lines.mapped('amount') if a < 0)
            return {'actual': {'analytic_revenue': revenue, 'analytic_cost': cost, 'analytic_net': revenue - cost}[measure]}
        if measure in VALUE_MEASURES:
            heads = len(self._employees())
            amount = self._sale_revenue(date_from, date_to) if measure == 'revenue_per_employee' else self._purchase_value(date_from, date_to)
            if amount is None or not heads:
                return None
            return {'num': amount, 'den': float(heads)}
        return None

    # ------------------------------------------------------------------ plan and score helpers
    def planned_value(self, kpi, date_from, date_to, to_date=True):
        """Planned value for the range. While the range is still running, only the plan up to today counts,
        so an open quarter is compared with what should have been achieved so far."""
        self.ensure_one()
        today = fields.Date.context_today(self)
        if to_date and date_from <= today < date_to:
            date_to = today
        plans = self.env['pe.plan'].sudo().search([('directorate_id', '=', self.id), ('state', '!=', 'cancel'),
                                                   ('date_start', '<=', date_to), ('date_end', '>=', date_from)],
                                                  order='state desc, date_start')
        lines = plans.mapped('line_ids').filtered(lambda l: l.kpi_id == kpi)
        if not lines:
            return None
        values = [line.amount_for(date_from, date_to) for line in lines]
        return sum(values) / len(values) if any(lines.mapped('is_average')) else sum(values)

    def score_for_range(self, date_from, date_to):
        """Score % of this directorate for a date range: the matching scorecard if there is one, else a live calculation."""
        self.ensure_one()
        card = self.env['pe.scorecard'].sudo().search([('directorate_id', '=', self.id), ('date_from', '=', date_from),
                                                       ('date_to', '=', date_to)], limit=1)
        if card:
            return card.score if card.has_data else None
        res = [kpi.evaluate(date_from, date_to) for kpi in self.kpi_ids.filtered('active')]
        res = [r for r in res if r['has_data']]
        own = None
        if res:
            den = sum(r['weight'] for r in res) or len(res)
            own = sum(r['capped'] * (r['weight'] or 1) for r in res) / den
        children = [(c.rollup_weight, c.score_for_range(date_from, date_to)) for c in self.child_ids.filtered('active')]
        return self._blend(own, children)

    def _blend(self, own, children):
        children = [(w or 0.0, s) for w, s in children if s is not None]
        child = None
        if children:
            tw = sum(w for w, _s in children)
            child = sum(w * s for w, s in children) / tw if tw else sum(s for _w, s in children) / len(children)
        if self.level != 'chief' or child is None:
            return own if own is not None else child
        if own is None:
            return child
        share = max(0.0, min(100.0, self.own_kpi_share)) / 100.0
        return own * share + child * (1 - share)

    # ------------------------------------------------------------------ actions
    def action_view_scorecards(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_scorecard')
        action['domain'] = [('directorate_id', '=', self.id)]
        action['context'] = {'default_directorate_id': self.id}
        return action

    def action_view_plans(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_plan')
        action['domain'] = [('directorate_id', '=', self.id)]
        action['context'] = {'default_directorate_id': self.id}
        return action

    def action_normalize_weights(self):
        for rec in self:
            kpis = rec.kpi_ids.filtered('active')
            total = sum(kpis.mapped('weight'))
            if kpis and total:
                for kpi in kpis:
                    kpi.weight = round(kpi.weight * 100.0 / total, 2)
            elif kpis:
                kpis.write({'weight': round(100.0 / len(kpis), 2)})
            rec.message_post(body=_('KPI weights rescaled to total 100%.'))

    def action_create_template(self):
        """Build an individual scorecard template whose KPIs read this directorate's results."""
        self.ensure_one()
        Template = self.env['pe.template']
        name = _('%s — Directorate scorecard') % self.name
        persps = self.env['pe.perspective'].search([])
        kpis = self.kpi_ids.filtered('active')
        total = sum(kpis.mapped('weight')) or len(kpis) or 1
        weights = {p.id: 0.0 for p in persps}
        lines = []
        for kpi in kpis:
            w = kpi.weight if sum(kpis.mapped('weight')) else 1.0
            weights[kpi.perspective_id.id] = weights.get(kpi.perspective_id.id, 0.0) + w * 100.0 / total
            lines.append((0, 0, {'sequence': kpi.sequence, 'perspective_id': kpi.perspective_id.id, 'major_function': kpi.code,
                                 'name': kpi.name, 'baseline': kpi.baseline, 'target': kpi.target or _('Plan'),
                                 'measure': kpi.formula, 'frequency': kpi.frequency, 'evidence': kpi.evidence or kpi.data_source,
                                 'source': 'dir_kpi', 'dir_kpi_id': kpi.id, 'kpi_weight': kpi.weight or 1.0}))
        # rounding: make the perspective weights add to exactly 100
        rounded = {pid: round(w, 2) for pid, w in weights.items()}
        if rounded and lines:
            top = max(rounded, key=lambda k: rounded[k])
            rounded[top] = round(rounded[top] + 100.0 - sum(rounded.values()), 2)
        vals = {'name': name, 'period_label': _('Directorate KPIs'), 'line_ids': [(5, 0, 0)] + lines,
                'weight_ids': [(5, 0, 0)] + [(0, 0, {'perspective_id': pid, 'weight': w}) for pid, w in rounded.items()]}
        template = Template.search([('name', '=', name)], limit=1)
        if template:
            template.write(vals)
        else:
            template = Template.create(vals)
        if self.director_id and not self.director_id.pe_template_id:
            self.director_id.sudo().pe_template_id = template
        self.message_post(body=_('Scorecard template %s updated from the directorate KPIs.') % template.name)
        return {'type': 'ir.actions.act_window', 'res_model': 'pe.template', 'res_id': template.id, 'view_mode': 'form'}


class PeDirectorateKpi(models.Model):
    _name = 'pe.directorate.kpi'
    _description = 'Directorate KPI'
    _order = 'directorate_id, sequence, code, id'

    directorate_id = fields.Many2one('pe.directorate', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='directorate_id.company_id', store=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    code = fields.Char('KPI code', required=True)
    name = fields.Char('KPI name', required=True)
    definition = fields.Text('KPI definition')
    strategic_objective = fields.Char()
    perspective_id = fields.Many2one('pe.perspective', string='BSC perspective', required=True,
                                     default=lambda self: self.env['pe.perspective'].search([], limit=1))
    formula = fields.Char()
    unit = fields.Char()
    baseline = fields.Char()
    weight = fields.Float('Weight %')
    target = fields.Char('Target', help='As written in the KPI sheet, e.g. ≥95%, ≤10%, ±5% Variance, Annual Target.')
    has_target = fields.Boolean('Numeric target', help='Untick when the target comes from the annual plan.')
    target_value = fields.Float('Target value')
    direction = fields.Selection(DIRECTIONS, default='higher', required=True)
    tolerance = fields.Float('± tolerance', help='For "within ± tolerance" KPIs, e.g. 5 for ±5% variance.')
    annual_target = fields.Char()
    threshold = fields.Char()
    threshold_value = fields.Float('Threshold (achievement %)',
                                   help='Below this achievement the KPI is red. 0 uses the general setting.')
    stretch_target = fields.Char()
    data_source = fields.Char()
    frequency = fields.Selection(FREQUENCY, default='monthly')
    kpi_owner = fields.Char()
    data_owner = fields.Char()
    reviewer = fields.Char()
    approver = fields.Char()
    evidence = fields.Char('Evidence required')
    measure = fields.Selection(MEASURES, string='Actual comes from', default='manual', required=True)
    calc_type = fields.Selection(CALC_TYPES, string='Calculation', default='ratio', required=True)
    owner_user_id = fields.Many2one('res.users', string='Responsible user',
                                    help='Gets the reminders to enter this KPI. Defaults to the director.')
    import_note = fields.Char(readonly=True)
    is_auto = fields.Boolean(compute='_compute_is_auto', store=True)

    _code_uniq = models.Constraint(
        'unique(directorate_id, code)',
        'KPI codes must be unique within a directorate.',
    )
    @api.depends('measure')
    def _compute_is_auto(self):
        for rec in self:
            rec.is_auto = rec.measure != 'manual'

    @api.depends('code', 'name')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '%s — %s' % (rec.code, rec.name) if rec.code else rec.name

    @api.onchange('measure')
    def _onchange_measure(self):
        if self.measure in RATIO_MEASURES:
            self.calc_type = 'ratio'
        elif self.measure in VALUE_MEASURES:
            self.calc_type = 'value'
        elif self.measure != 'manual' and self.calc_type == 'ratio':
            self.calc_type = 'plan'

    def responsible_user(self):
        self.ensure_one()
        return self.owner_user_id or self.directorate_id.director_id.user_id

    def in_scope(self, date_from, date_to):
        """A KPI joins a scorecard when the scorecard spans at least its reporting frequency."""
        self.ensure_one()
        return self.is_auto or FREQ_MONTHS.get(self.frequency or 'monthly', 1) <= months_between(date_from, date_to)

    # ------------------------------------------------------------------ scoring
    def evaluate(self, date_from, date_to, manual=None, planned=None, fetch=True):
        """Compute one KPI for a date range.

        manual: dict with actual / num / den entered by the data owner (manual KPIs).
        planned: plan value if already known; otherwise read from the annual plan.
        """
        self.ensure_one()
        directorate = self.directorate_id
        if planned is None:
            planned = directorate.planned_value(self, date_from, date_to)
        data = {}
        if self.is_auto and fetch:
            data = directorate.measure_value(self.measure, date_from, date_to) or {}
        elif manual:
            data = {k: v for k, v in manual.items() if v is not None}
        return self.score_values(planned, data.get('actual'), data.get('num'), data.get('den'))

    def score_values(self, planned, actual, num, den):
        self.ensure_one()
        cap = param_float(self.env, 'dir_cap', 120.0)
        green = param_float(self.env, 'dir_green', 95.0)
        amber = self.threshold_value or param_float(self.env, 'dir_amber', 80.0)
        calc = self.calc_type
        result = None
        if calc == 'plan':
            if planned and actual is not None:
                result = actual / planned * 100.0
        elif calc == 'plan_inv':
            if planned and actual:
                result = planned / actual * 100.0
        elif calc == 'variance':
            if planned and actual is not None:
                result = (actual - planned) / planned * 100.0
        elif calc == 'ratio':
            if den:
                result = (num or 0.0) / den * 100.0
            elif actual is not None:
                result = actual
        else:  # value
            if den:
                result = (num or 0.0) / den
            elif actual is not None:
                result = actual
        if self.has_target or self.direction == 'band':
            target = self.target_value
        elif calc in ('plan', 'plan_inv', 'ratio'):
            target = 100.0
        elif calc == 'variance':
            target = 0.0
        else:
            target = planned
        achievement = None
        if result is not None and target is not None:
            if self.direction == 'band':
                dev = abs(result - target)
                tol = self.tolerance or 0.0
                achievement = 100.0 if dev <= tol else max(0.0, 100.0 * tol / dev if tol else 100.0 - dev)
            elif self.direction == 'lower':
                achievement = target / result * 100.0 if result > 0 else 100.0 + (cap - 100.0)
            else:
                if target > 0:
                    achievement = result / target * 100.0
                elif target == 0:
                    achievement = 100.0 if result >= 0 else 0.0
        has = achievement is not None
        capped = max(0.0, min(achievement, cap)) if has else 0.0
        status = 'nodata' if not has else ('green' if achievement >= green else 'amber' if achievement >= amber else 'red')
        return {'planned': planned, 'actual': actual, 'num': num, 'den': den, 'result': result, 'target': target,
                'achievement': achievement if has else 0.0, 'capped': capped, 'has_data': has, 'status': status,
                'weight': self.weight}
