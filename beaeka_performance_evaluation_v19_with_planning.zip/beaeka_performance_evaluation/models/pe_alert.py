from odoo import api, fields, models, _

from .pe_config import param_float

SEVERITY = [('high', 'High'), ('medium', 'Medium'), ('info', 'Info')]
ALERT_TYPES = [
    ('missing', 'Missing evaluation'),
    ('overdue', 'Overdue'),
    ('due_soon', 'Due soon'),
    ('weights', 'Weights not 100%'),
    ('pip', 'Improvement plan required'),
    ('low', 'Below expectation'),
    ('kpi_gap', 'KPI below target'),
    ('no_supervisor', 'No supervisor'),
    ('low_leadership', 'Low leadership score'),
    ('dir_low', 'Directorate score low'),
    ('dir_red', 'Directorate KPIs off track'),
    ('dir_nodata', 'Directorate KPI data missing'),
    ('dir_setup', 'Directorate setup'),
]


class PeAlert(models.Model):
    _name = 'pe.alert'
    _description = 'Performance Evaluation Alert'
    _order = 'severity_order, alert_type, id'

    period_id = fields.Many2one('pe.period', required=True, ondelete='cascade', index=True)
    severity = fields.Selection(SEVERITY, required=True)
    severity_order = fields.Integer(compute='_compute_severity_order', store=True)
    alert_type = fields.Selection(ALERT_TYPES, string='Type', required=True)
    employee_id = fields.Many2one('hr.employee', ondelete='cascade')
    department_id = fields.Many2one(related='employee_id.department_id', store=True)
    manager_id = fields.Many2one(related='employee_id.parent_id', store=True, string='Supervisor')
    company_id = fields.Many2one(related='employee_id.company_id', store=True)
    evaluation_id = fields.Many2one('pe.evaluation', ondelete='cascade')
    directorate_id = fields.Many2one('pe.directorate', ondelete='cascade', index=True)
    scorecard_id = fields.Many2one('pe.scorecard', ondelete='cascade')
    message = fields.Char(required=True)

    @api.depends('severity')
    def _compute_severity_order(self):
        order = {'high': 0, 'medium': 1, 'info': 2}
        for rec in self:
            rec.severity_order = order.get(rec.severity, 3)

    @api.model
    def refresh_alerts(self, period=None):
        period = period or self.env['pe.period'].get_current()
        if not period:
            return False
        self.sudo().search([('period_id', '=', period.id)]).unlink()
        today = fields.Date.context_today(self)
        due_days = int(param_float(self.env, 'due_days', 7))
        low = param_float(self.env, 'low_score', 60)
        pip = param_float(self.env, 'pip_score', 50)
        gap = param_float(self.env, 'kpi_gap', 80)
        lead_min = param_float(self.env, 'lead_min', 3)
        min_n = int(param_float(self.env, 'min_responses', 3))
        vals = []

        def add(sev, typ, emp, msg, ev=None):
            vals.append({'period_id': period.id, 'severity': sev, 'alert_type': typ, 'employee_id': emp.id,
                         'evaluation_id': ev.id if ev else False, 'message': msg})

        employees = self.env['hr.employee'].sudo().search([('pe_excluded', '=', False)])
        evals = self.env['pe.evaluation'].sudo().search([('period_id', '=', period.id)])
        have = set(evals.mapped('employee_id').ids)
        for emp in employees:
            if emp.id not in have:
                add('medium', 'missing', emp, _('No %s evaluation has been started.') % period.name)
            if not emp.parent_id and (emp.pe_form_type_id.code or '') != 'A':
                add('info', 'no_supervisor', emp, _('Assign a supervisor (Manager) so the evaluation can be routed.'))
            st = self.env['pe.leadership.response'].stats(period, emp)
            if st['n'] >= min_n and st['avg'] < lead_min:
                add('medium', 'low_leadership', emp, _('Leadership survey average %(a).2f/5 from %(n)s responses, below %(m)s/5.',
                                                       a=st['avg'], n=st['n'], m=lead_min))
        for ev in evals:
            emp = ev.employee_id
            if ev.state != 'done' and ev.due_date:
                if ev.due_date < today:
                    add('high', 'overdue', emp, _('%(r)s is %(d)s day(s) past due, still in %(s)s.', r=ev.name,
                                                  d=(today - ev.due_date).days, s=dict(ev._fields['state'].selection)[ev.state]), ev)
                elif (ev.due_date - today).days <= due_days:
                    add('medium', 'due_soon', emp, _('%(r)s is due on %(d)s.', r=ev.name, d=ev.due_date), ev)
            if ev.state != 'done' and (abs(ev.perspective_weight_total - 100) > 0.01 or abs(ev.kpi_weight_total - 100) > 0.01):
                add('medium', 'weights', emp, _('%(r)s: KPI weights total %(w).1f%%.', r=ev.name, w=ev.kpi_weight_total), ev)
            if ev.state in ('calib', 'done') and ev.band_id:
                if ev.total_score < pip:
                    add('high', 'pip', emp, _('%(r)s scored %(s).1f%%, below the %(p)s%% improvement-plan line.', r=ev.name, s=ev.total_score, p=pip), ev)
                elif ev.total_score < low:
                    add('medium', 'low', emp, _('%(r)s scored %(s).1f%%, below the %(p)s%% expectation line.', r=ev.name, s=ev.total_score, p=low), ev)
            if ev.state != 'draft':
                under = ev.kpi_ids.filtered(lambda l: l.has_achievement and l.achievement < gap)
                if under:
                    add('info', 'kpi_gap', emp, _('%(n)s KPI(s) under %(g)s%% of target: %(k)s', n=len(under), g=gap,
                                                  k='; '.join((under.mapped('name') or [])[:3])), ev)
        vals += self._directorate_alerts(period, low, pip)
        self.sudo().create(vals)
        return True

    @api.model
    def _directorate_alerts(self, period, low, pip):
        vals = []
        today = fields.Date.context_today(self)

        def add(sev, typ, directorate, msg, card=None):
            vals.append({'period_id': period.id, 'severity': sev, 'alert_type': typ, 'message': msg,
                         'employee_id': directorate.director_id.id or False, 'directorate_id': directorate.id,
                         'scorecard_id': card.id if card else False})

        for directorate in self.env['pe.directorate'].sudo().search([]):
            if not directorate.director_id:
                add('info', 'dir_setup', directorate, _('%s has no Director / Chief: notifications cannot be routed.') % directorate.name)
            if directorate.kpi_ids and not directorate.weight_ok:
                add('info', 'dir_setup', directorate, _('%(d)s: KPI weights total %(w).1f%%, not 100%%.',
                                                        d=directorate.name, w=directorate.weight_total))
            if directorate.link_warning:
                add('info', 'dir_setup', directorate, directorate.link_warning)
        cards = self.env['pe.scorecard'].sudo().search([('date_from', '<=', period.date_end or today),
                                                         ('date_to', '>=', period.date_start or today)])
        for card in cards:
            d = card.directorate_id
            if card.has_data and card.state != 'open':
                if card.score < pip:
                    add('high', 'dir_low', d, _('%(c)s scored %(s).1f%%, below the %(p)s%% improvement-plan line.',
                                                c=card.name, s=card.score, p=pip), card)
                elif card.score < low:
                    add('medium', 'dir_low', d, _('%(c)s scored %(s).1f%%, below the %(p)s%% expectation line.',
                                                  c=card.name, s=card.score, p=low), card)
            if card.state != 'done' and card.red_count:
                red = card.line_ids.filtered(lambda l: l.status == 'red')
                add('medium', 'dir_red', d, _('%(c)s: %(n)s KPI(s) off track: %(k)s', c=card.name, n=len(red),
                                              k=', '.join(red.mapped('code')[:6])), card)
            if card.state == 'review' and card.missing_count:
                add('high', 'dir_nodata', d, _('%(c)s ended; %(n)s KPI(s) still have no data.', c=card.name, n=card.missing_count), card)
        return vals

    @api.model
    def action_refresh(self):
        self.refresh_alerts()
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    @api.model
    def _cron_refresh(self):
        self.env['pe.scorecard']._cron_auto_evaluate()
        self.refresh_alerts()
        # remind the person who holds an overdue evaluation
        today = fields.Date.context_today(self)
        overdue = self.env['pe.evaluation'].sudo().search([('state', 'in', ('self', 'manager', 'calib')), ('due_date', '<', today)])
        for ev in overdue:
            user = ev.employee_id.user_id if ev.state == 'self' else ev.manager_id.user_id if ev.state == 'manager' else False
            if not user:
                continue
            summary = _('Overdue evaluation')
            if not ev.activity_ids.filtered(lambda a: a.summary == summary and a.user_id == user):
                ev.activity_schedule('mail.mail_activity_data_todo', date_deadline=today, user_id=user.id, summary=summary)

    def action_open(self):
        self.ensure_one()
        target = self.evaluation_id or self.scorecard_id or self.directorate_id or self.employee_id
        return {'type': 'ir.actions.act_window', 'res_model': target._name, 'res_id': target.id, 'view_mode': 'form'}
