import re

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

FREQUENCY = [
    ('monthly', 'Monthly'),
    ('quarterly', 'Quarterly'),
    ('semi', 'Semi-annual'),
    ('annual', 'Annual'),
    ('seasonal', 'Seasonal'),
]
SOURCE = [
    ('manual', 'Manual entry'),
    ('prc', 'System: evaluation completion %'),
    ('lead_all', 'Survey: leadership score, all leaders'),
    ('lead_self', 'Survey: leadership score, this employee'),
    ('eng', 'Survey: engagement positive %'),
    ('enps', 'Survey: eNPS'),
    ('dir_kpi', 'Directorate KPI: result and achievement'),
    ('dir_score', 'Directorate scorecard: total score'),
]
LINE_FIELDS = ['sequence', 'perspective_id', 'major_function', 'name', 'baseline', 'target',
               'measure', 'frequency', 'evidence', 'initiatives', 'source', 'dir_kpi_id', 'kpi_weight']


def parse_target(text):
    """Return (number, lower_is_better) from targets such as '>=75%', '<=20 days', '>=3/5'."""
    s = text or ''
    m = re.search(r'-?\d+(?:\.\d+)?', s.replace(',', ''))
    return (float(m.group(0)) if m else None, bool(re.search(r'≤|<=|<|\bmax', s, re.I)))


def to_number(text):
    if text in (None, False, ''):
        return None
    m = re.search(r'-?\d+(?:\.\d+)?', str(text).replace(',', ''))
    return float(m.group(0)) if m else None


def param_float(env, key, default):
    val = env['ir.config_parameter'].sudo().get_param('beaeka_pe.' + key)
    try:
        return float(val) if val not in (None, False, '') else default
    except ValueError:
        return default


def param_bool(env, key, default=False):
    icp = env['ir.config_parameter'].sudo()
    val = icp.get_param('beaeka_pe.' + key)
    if val in (None, False, ''):
        # once the settings were saved, a missing boolean means "unticked" (Odoo deletes False parameters)
        return False if icp.get_param('beaeka_pe.settings_saved') else default
    return str(val).lower() in ('1', 'true', 'yes')


def param_str(env, key, default=''):
    return env['ir.config_parameter'].sudo().get_param('beaeka_pe.' + key) or default


def line_vals(rec):
    vals = {}
    for f in LINE_FIELDS:
        v = rec[f]
        vals[f] = v.id if isinstance(v, models.BaseModel) else v
    return vals


class PeRating(models.Model):
    _name = 'pe.rating'
    _description = 'Rating Scale'
    _order = 'value desc'

    name = fields.Char(required=True, translate=True)
    value = fields.Integer(required=True)

    _value_uniq = models.Constraint(
        'unique(value)',
        'Each rating value must be unique.',
    )
    @api.depends('name', 'value')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '%s — %s' % (rec.value, rec.name or '')

    @api.model
    def max_value(self):
        top = self.sudo().search([], order='value desc', limit=1)
        return top.value or 5


class PeScoreBand(models.Model):
    _name = 'pe.score.band'
    _description = 'Score Band'
    _order = 'min_score desc'

    name = fields.Char(required=True, translate=True)
    min_score = fields.Float('From score (%)', required=True)
    color = fields.Integer()

    @api.model
    def band_for(self, score):
        for band in self.sudo().search([], order='min_score desc'):
            if score >= band.min_score:
                return band
        return self.browse()


class PeFormType(models.Model):
    _name = 'pe.form.type'
    _description = 'Evaluation Form Type'
    _order = 'code'

    code = fields.Char(required=True)
    name = fields.Char(required=True, translate=True)
    company_weight = fields.Float('Company BSC %')
    individual_weight = fields.Float('Individual KPIs %')
    competency_weight = fields.Float('Competencies %')
    total_weight = fields.Float(compute='_compute_total_weight')

    @api.depends('company_weight', 'individual_weight', 'competency_weight')
    def _compute_total_weight(self):
        for rec in self:
            rec.total_weight = rec.company_weight + rec.individual_weight + rec.competency_weight

    @api.constrains('company_weight', 'individual_weight', 'competency_weight')
    def _check_total(self):
        for rec in self:
            total = rec.company_weight + rec.individual_weight + rec.competency_weight
            if abs(total - 100) > 0.01:
                raise ValidationError(_('Form %(code)s: section weights must total 100%% (now %(total).1f%%).',
                                        code=rec.code, total=total))

    @api.depends('code', 'name')
    def _compute_display_name(self):
        for rec in self:
            rec.display_name = '%s: %s' % (rec.code or '', rec.name or '')


class PePerspective(models.Model):
    _name = 'pe.perspective'
    _description = 'BSC Perspective'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    default_weight = fields.Float('Default weight %')


class PeCompetency(models.Model):
    _name = 'pe.competency'
    _description = 'Competency'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    weight = fields.Float('Weight %')
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)


class PePeriod(models.Model):
    _name = 'pe.period'
    _description = 'Evaluation Period'
    _order = 'date_start desc, id desc'

    name = fields.Char(required=True)
    date_start = fields.Date()
    date_end = fields.Date()
    due_date = fields.Date('Default due date')
    is_current = fields.Boolean('Current period', readonly=True, copy=False)
    active = fields.Boolean(default=True)
    bsc_line_ids = fields.One2many('pe.company.bsc.line', 'period_id', string='Company BSC', copy=True)
    bsc_score = fields.Float('Company BSC score %', compute='_compute_bsc_score')
    bsc_rated = fields.Boolean(compute='_compute_bsc_score')
    bsc_weight_total = fields.Float(compute='_compute_bsc_score')
    evaluation_count = fields.Integer(compute='_compute_evaluation_count')

    @api.depends('bsc_line_ids.weight', 'bsc_line_ids.rating_id')
    def _compute_bsc_score(self):
        maxv = self.env['pe.rating'].max_value()
        for rec in self:
            num = den = 0.0
            for line in rec.bsc_line_ids:
                if line.rating_id:
                    den += line.weight
                    num += line.weight * line.rating_id.value / maxv
            rec.bsc_rated = bool(den)
            rec.bsc_score = num / den * 100 if den else 0.0
            rec.bsc_weight_total = sum(rec.bsc_line_ids.mapped('weight'))

    def _compute_evaluation_count(self):
        data = self.env['pe.evaluation']._read_group([('period_id', 'in', self.ids)], ['period_id'], ['__count'])
        counts = {period.id: count for period, count in data}
        for rec in self:
            rec.evaluation_count = counts.get(rec.id, 0)

    @api.model
    def get_current(self):
        return self.search([('is_current', '=', True)], limit=1)

    def action_set_current(self):
        self.ensure_one()
        self.search([('is_current', '=', True)]).write({'is_current': False})
        self.is_current = True

    def action_view_evaluations(self):
        self.ensure_one()
        action = self.env['ir.actions.act_window']._for_xml_id('beaeka_performance_evaluation.action_pe_evaluation')
        action['domain'] = [('period_id', '=', self.id)]
        action['context'] = {'default_period_id': self.id}
        return action

    def action_print_summary(self):
        return self.env.ref('beaeka_performance_evaluation.action_report_pe_period_summary').report_action(self)


class PeCompanyBscLine(models.Model):
    _name = 'pe.company.bsc.line'
    _description = 'Company BSC Line'
    _order = 'sequence, id'

    period_id = fields.Many2one('pe.period', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    kra = fields.Char('KRA pillar', required=True)
    name = fields.Char('Company KPI')
    target = fields.Char()
    weight = fields.Float('Weight %')
    rating_id = fields.Many2one('pe.rating', string='Achieved rating')


class PeTemplate(models.Model):
    _name = 'pe.template'
    _description = 'KPI Scorecard Template'
    _order = 'name'

    name = fields.Char(required=True)
    period_label = fields.Char()
    active = fields.Boolean(default=True)
    weight_ids = fields.One2many('pe.template.weight', 'template_id', string='Perspective weights', copy=True,
                                 default=lambda self: [(0, 0, {'perspective_id': p.id, 'weight': p.default_weight})
                                                       for p in self.env['pe.perspective'].search([])])
    line_ids = fields.One2many('pe.template.line', 'template_id', string='KPIs', copy=True)
    weight_total = fields.Float(compute='_compute_totals')
    line_count = fields.Integer(compute='_compute_totals')
    employee_count = fields.Integer(compute='_compute_employee_count')

    @api.depends('weight_ids.weight', 'line_ids')
    def _compute_totals(self):
        for rec in self:
            rec.weight_total = sum(rec.weight_ids.mapped('weight'))
            rec.line_count = len(rec.line_ids)

    def _compute_employee_count(self):
        for rec in self:
            rec.employee_count = self.env['hr.employee'].sudo().search_count([('pe_template_id', '=', rec.id)])

    def action_add_missing_perspectives(self):
        persps = self.env['pe.perspective'].search([])
        for rec in self:
            missing = persps - rec.weight_ids.mapped('perspective_id')
            if missing:
                rec.weight_ids = [(0, 0, {'perspective_id': p.id, 'weight': 0.0}) for p in missing]


class PeTemplateWeight(models.Model):
    _name = 'pe.template.weight'
    _description = 'Template Perspective Weight'
    _order = 'sequence, id'

    template_id = fields.Many2one('pe.template', required=True, ondelete='cascade')
    perspective_id = fields.Many2one('pe.perspective', required=True)
    sequence = fields.Integer(related='perspective_id.sequence', store=True)
    weight = fields.Float('Weight %')


class PeTemplateLine(models.Model):
    _name = 'pe.template.line'
    _description = 'Template KPI'
    _order = 'sequence, id'

    template_id = fields.Many2one('pe.template', required=True, ondelete='cascade')
    sequence = fields.Integer(default=10)
    perspective_id = fields.Many2one('pe.perspective', required=True)
    major_function = fields.Char()
    name = fields.Char('KPI', required=True)
    baseline = fields.Char()
    target = fields.Char()
    measure = fields.Char('How to measure')
    frequency = fields.Selection(FREQUENCY)
    evidence = fields.Char()
    initiatives = fields.Char('Priority initiatives')
    source = fields.Selection(SOURCE, string='Actual comes from', default='manual', required=True)
    dir_kpi_id = fields.Many2one('pe.directorate.kpi', string='Directorate KPI')
    kpi_weight = fields.Float('KPI weight', help='Optional. When set, the perspective weight is shared in proportion '
                                                 'to these weights instead of equally.')
